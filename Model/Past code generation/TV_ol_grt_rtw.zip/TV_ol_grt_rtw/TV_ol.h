/*
 * TV_ol.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TV_ol".
 *
 * Model version              : 3.15
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Sat Jan 13 17:12:32 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_TV_ol_h_
#define RTW_HEADER_TV_ol_h_
#ifndef TV_ol_COMMON_INCLUDES_
#define TV_ol_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* TV_ol_COMMON_INCLUDES_ */

#include "TV_ol_types.h"
#include "rt_nonfinite.h"
#include <float.h>
#include <string.h>
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T DeadZone;                     /* '<S3>/Dead Zone' */
  real_T Abs;                          /* '<S3>/Abs' */
  real_T Sign;                         /* '<S3>/Sign' */
  real_T last_x[6];                    /* '<S13>/last_x' */
  real_T last_mv;                      /* '<S13>/last_mv' */
  real_T VectorConcatenate[3];         /* '<S10>/Vector Concatenate' */
  real_T Steeringangleatwheelsdegs;    /* '<S6>/Gain1' */
  real_T Fcn2;                         /* '<S6>/Fcn2' */
  real_T Product;                      /* '<S6>/Product' */
  real_T Square;                       /* '<S6>/Square' */
  real_T Gain;                         /* '<S6>/Gain' */
  real_T Plus;                         /* '<S6>/Plus' */
  real_T Desiredyawratereferencedegs;  /* '<S6>/Divide' */
  real_T Product1;                     /* '<S6>/Product1' */
  real_T Upperlimitrads;               /* '<S6>/Divide1' */
  real_T Gain2;                        /* '<S6>/Gain2' */
  real_T VectorConcatenate1[3];        /* '<S10>/Vector Concatenate1' */
  real_T umin_scale4;                  /* '<S13>/umin_scale4' */
  real_T ymin_scale1[3];               /* '<S13>/ymin_scale1' */
  real_T ymin_scale2;                  /* '<S13>/ymin_scale2' */
  real_T extmv_scale;                  /* '<S13>/ext.mv_scale' */
  real_T uref_scale;                   /* '<S13>/uref_scale' */
  real_T MathFunction[3];              /* '<S13>/Math Function' */
  real_T MathFunction1;                /* '<S13>/Math Function1' */
  real_T MathFunction2;                /* '<S13>/Math Function2' */
  real_T LastPcov[36];                 /* '<S13>/LastPcov' */
  real_T u_scale;                      /* '<S13>/u_scale' */
  real_T NominalU1;                    /* '<S10>/NominalU1' */
  real_T Yawmomentsaturation;          /* '<S8>/Yaw moment saturation' */
  real_T Product2;                     /* '<S8>/Product2' */
  real_T Yawmomentsaturation_a;        /* '<S5>/Yaw moment saturation' */
  real_T Gain3;                        /* '<S7>/Gain3' */
  real_T Gain1;                        /* '<S7>/Gain1' */
  real_T Desiredtorquedifferenceatfronta;/* '<S7>/Divide1' */
  real_T Gain2_m;                      /* '<S7>/Gain2' */
  real_T Gain_g;                       /* '<S7>/Gain' */
  real_T Desiredtorquedifferenceatrearax;/* '<S7>/Divide2' */
  real_T A[9];                         /* '<S10>/MATLAB Function' */
  real_T B[3];                         /* '<S10>/MATLAB Function' */
  real_T C[9];                         /* '<S10>/MATLAB Function' */
  real_T D[3];                         /* '<S10>/MATLAB Function' */
  real_T U;                            /* '<S10>/MATLAB Function' */
  real_T Y[3];                         /* '<S10>/MATLAB Function' */
  real_T X[3];                         /* '<S10>/MATLAB Function' */
  real_T DX[3];                        /* '<S10>/MATLAB Function' */
  real_T xk1[6];                       /* '<S41>/FixedHorizonOptimizer' */
  real_T u;                            /* '<S41>/FixedHorizonOptimizer' */
  real_T cost;                         /* '<S41>/FixedHorizonOptimizer' */
  real_T useq[11];                     /* '<S41>/FixedHorizonOptimizer' */
  real_T xseq[66];                     /* '<S41>/FixedHorizonOptimizer' */
  real_T yseq[33];                     /* '<S41>/FixedHorizonOptimizer' */
  real_T status;                       /* '<S41>/FixedHorizonOptimizer' */
  real_T xest[6];                      /* '<S41>/FixedHorizonOptimizer' */
  real_T Pk1[36];                      /* '<S41>/FixedHorizonOptimizer' */
  boolean_T Compare;                   /* '<S2>/Compare' */
  boolean_T TVactivation;              /* '<S1>/AND' */
  boolean_T AND;                       /* '<S8>/AND' */
  boolean_T Memory;                    /* '<S13>/Memory' */
  boolean_T iAout;                     /* '<S41>/FixedHorizonOptimizer' */
} B_TV_ol_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T last_mv_DSTATE;               /* '<S13>/last_mv' */
  real_T last_x_PreviousInput[6];      /* '<S13>/last_x' */
  real_T LastPcov_PreviousInput[36];   /* '<S13>/LastPcov' */
  boolean_T Memory_PreviousInput;      /* '<S13>/Memory' */
} DW_TV_ol_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T StrAngleDeg;                  /* '<Root>/StrAngleDeg' */
  real_T VehicleSpeed;                 /* '<Root>/VehicleSpeed' */
  real_T TorqueVectoringEnabled;       /* '<Root>/TorqueVectoringEnabled' */
  real_T VehicleYawRate;               /* '<Root>/VehicleYawRate' */
  boolean_T FeedbackEnabled;           /* '<Root>/FeedbackEnabled' */
  boolean_T FeedForwardEnabled;        /* '<Root>/FeedForwardEnabled' */
  real_T LateralVelocity;              /* '<Root>/LateralVelocity' */
} ExtU_TV_ol_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T TVFL;                         /* '<Root>/TVFL' */
  real_T TVFR;                         /* '<Root>/TVFR' */
  real_T TVRL;                         /* '<Root>/TVRL' */
  real_T TVRR;                         /* '<Root>/TVRR' */
} ExtY_TV_ol_T;

/* Parameters (default storage) */
struct P_TV_ol_T_ {
  real_T Gr;                           /* Variable: Gr
                                        * Referenced by:
                                        *   '<S7>/Constant'
                                        *   '<S7>/Constant1'
                                        */
  real_T Ku;                           /* Variable: Ku
                                        * Referenced by: '<S6>/Gain'
                                        */
  real_T LowerYawMoment;               /* Variable: LowerYawMoment
                                        * Referenced by:
                                        *   '<S5>/Yaw moment saturation'
                                        *   '<S8>/Yaw moment saturation'
                                        */
  real_T Rd;                           /* Variable: Rd
                                        * Referenced by:
                                        *   '<S7>/Gain'
                                        *   '<S7>/Gain1'
                                        */
  real_T Sgr;                          /* Variable: Sgr
                                        * Referenced by: '<S6>/Gain1'
                                        */
  real_T SteeringDeadzonelimit;        /* Variable: SteeringDeadzonelimit
                                        * Referenced by: '<S3>/Dead Zone'
                                        */
  real_T UpperYawMoment;               /* Variable: UpperYawMoment
                                        * Referenced by:
                                        *   '<S5>/Yaw moment saturation'
                                        *   '<S8>/Yaw moment saturation'
                                        */
  real_T g;                            /* Variable: g
                                        * Referenced by: '<S6>/Constant2'
                                        */
  real_T l;                            /* Variable: l
                                        * Referenced by: '<S6>/Constant'
                                        */
  real_T myy;                          /* Variable: myy
                                        * Referenced by: '<S6>/Constant1'
                                        */
  real_T wf;                           /* Variable: wf
                                        * Referenced by: '<S7>/Constant1'
                                        */
  real_T wr;                           /* Variable: wr
                                        * Referenced by: '<S7>/Constant'
                                        */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S2>/Constant'
                                       */
  real_T last_x_InitialCondition[6];   /* Expression: lastx+xoff
                                        * Referenced by: '<S13>/last_x'
                                        */
  real_T last_mv_InitialCondition;     /* Expression: lastu+uoff
                                        * Referenced by: '<S13>/last_mv'
                                        */
  real_T Gain2_Gain;                   /* Expression: 180/pi
                                        * Referenced by: '<S6>/Gain2'
                                        */
  real_T md_zero_Value;                /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/md_zero'
                                        */
  real_T umin_zero_Value;              /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/umin_zero'
                                        */
  real_T umax_zero_Value;              /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/umax_zero'
                                        */
  real_T ymin_zero_Value[3];           /* Expression: zeros(3,1)
                                        * Referenced by: '<S11>/ymin_zero'
                                        */
  real_T ymax_zero_Value[3];           /* Expression: zeros(3,1)
                                        * Referenced by: '<S11>/ymax_zero'
                                        */
  real_T E_zero_Value;                 /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/E_zero'
                                        */
  real_T umin_scale4_Gain;         /* Expression: MVscale(:,ones(1,max(nCC,1)))'
                                    * Referenced by: '<S13>/umin_scale4'
                                    */
  real_T F_zero_Value[3];              /* Expression: zeros(1,3)
                                        * Referenced by: '<S11>/F_zero'
                                        */
  real_T ymin_scale1_Gain[3];       /* Expression: Yscale(:,ones(1,max(nCC,1)))'
                                     * Referenced by: '<S13>/ymin_scale1'
                                     */
  real_T G_zero_Value;                 /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/G_zero'
                                        */
  real_T S_zero_Value;                 /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/S_zero'
                                        */
  real_T ymin_scale2_Gain;         /* Expression: MDscale(:,ones(1,max(nCC,1)))'
                                    * Referenced by: '<S13>/ymin_scale2'
                                    */
  real_T switch_zero_Value;            /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/switch_zero'
                                        */
  real_T extmv_zero_Value;             /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/ext.mv_zero'
                                        */
  real_T extmv_scale_Gain;             /* Expression: RMVscale
                                        * Referenced by: '<S13>/ext.mv_scale'
                                        */
  real_T mvtarget_zero_Value;          /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/mv.target_zero'
                                        */
  real_T uref_scale_Gain;              /* Expression: RMVscale
                                        * Referenced by: '<S13>/uref_scale'
                                        */
  real_T ywt_zero_Value[3];            /* Expression: zeros(3,1)
                                        * Referenced by: '<S11>/y.wt_zero'
                                        */
  real_T uwt_zero_Value;               /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/u.wt_zero'
                                        */
  real_T duwt_zero_Value;              /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/du.wt_zero'
                                        */
  real_T ecrwt_zero_Value;             /* Expression: zeros(1,1)
                                        * Referenced by: '<S11>/ecr.wt_zero'
                                        */
  real_T LastPcov_InitialCondition[36];/* Expression: lastPcov
                                        * Referenced by: '<S13>/LastPcov'
                                        */
  real_T u_scale_Gain;                 /* Expression: MVscale
                                        * Referenced by: '<S13>/u_scale'
                                        */
  real_T NominalU1_Bias;               /* Expression: 0
                                        * Referenced by: '<S10>/NominalU1'
                                        */
  real_T Gain3_Gain;                   /* Expression: 0.5
                                        * Referenced by: '<S7>/Gain3'
                                        */
  real_T Gain_Gain;                    /* Expression: 0.5
                                        * Referenced by: '<S4>/Gain'
                                        */
  real_T Gain2_Gain_o;                 /* Expression: 0.5
                                        * Referenced by: '<S7>/Gain2'
                                        */
  real_T Gain1_Gain;                   /* Expression: 0.5
                                        * Referenced by: '<S4>/Gain1'
                                        */
  int32_T FixedHorizonOptimizer_Ndis;  /* Expression: Ndis
                                        * Referenced by: '<S41>/FixedHorizonOptimizer'
                                        */
  boolean_T Memory_InitialCondition;   /* Expression: iA
                                        * Referenced by: '<S13>/Memory'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_TV_ol_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_TV_ol_T TV_ol_P;

/* Block signals (default storage) */
extern B_TV_ol_T TV_ol_B;

/* Block states (default storage) */
extern DW_TV_ol_T TV_ol_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_TV_ol_T TV_ol_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_TV_ol_T TV_ol_Y;

/* Model entry point functions */
extern void TV_ol_initialize(void);
extern void TV_ol_step(void);
extern void TV_ol_terminate(void);

/* Real-time Model object */
extern RT_MODEL_TV_ol_T *const TV_ol_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S13>/Floor' : Unused code path elimination
 * Block '<S13>/Floor1' : Unused code path elimination
 * Block '<S14>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S15>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S16>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S17>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S18>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S19>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S20>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S21>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S22>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S23>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S24>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S25>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S26>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S27>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S28>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S29>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S30>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S31>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S32>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S33>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S34>/Vector Dimension Check' : Unused code path elimination
 * Block '<S35>/Vector Dimension Check' : Unused code path elimination
 * Block '<S36>/Vector Dimension Check' : Unused code path elimination
 * Block '<S37>/Vector Dimension Check' : Unused code path elimination
 * Block '<S38>/Vector Dimension Check' : Unused code path elimination
 * Block '<S39>/Vector Dimension Check' : Unused code path elimination
 * Block '<S40>/Vector Dimension Check' : Unused code path elimination
 * Block '<S13>/useq_scale' : Unused code path elimination
 * Block '<S13>/useq_scale1' : Unused code path elimination
 * Block '<S13>/ym_zero' : Unused code path elimination
 * Block '<S11>/m_zero' : Unused code path elimination
 * Block '<S11>/p_zero' : Unused code path elimination
 * Block '<S9>/AND' : Unused code path elimination
 * Block '<S9>/Constant' : Unused code path elimination
 * Block '<S9>/Product' : Unused code path elimination
 * Block '<S9>/Product2' : Unused code path elimination
 * Block '<S9>/Yaw moment saturation' : Unused code path elimination
 * Block '<S13>/Reshape' : Reshape block reduction
 * Block '<S13>/Reshape1' : Reshape block reduction
 * Block '<S13>/Reshape2' : Reshape block reduction
 * Block '<S13>/Reshape3' : Reshape block reduction
 * Block '<S13>/Reshape4' : Reshape block reduction
 * Block '<S13>/Reshape5' : Reshape block reduction
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'TV_ol'
 * '<S1>'   : 'TV_ol/Subsystem'
 * '<S2>'   : 'TV_ol/Subsystem/Compare To Constant'
 * '<S3>'   : 'TV_ol/Subsystem/If steering angle is between -10 and 10 degrees system is off '
 * '<S4>'   : 'TV_ol/Subsystem/Yaw moment distribution'
 * '<S5>'   : 'TV_ol/Subsystem/Yaw rate controller'
 * '<S6>'   : 'TV_ol/Subsystem/Yaw rate reference calculation'
 * '<S7>'   : 'TV_ol/Subsystem/Yaw moment distribution/Lateral torque distribution'
 * '<S8>'   : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type'
 * '<S9>'   : 'TV_ol/Subsystem/Yaw rate controller/Feedforward controller type'
 * '<S10>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type'
 * '<S11>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller'
 * '<S12>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/MATLAB Function'
 * '<S13>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC'
 * '<S14>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check'
 * '<S15>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check A'
 * '<S16>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check B'
 * '<S17>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check C'
 * '<S18>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check D'
 * '<S19>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check DX'
 * '<S20>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check U'
 * '<S21>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check X'
 * '<S22>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check Y'
 * '<S23>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check1'
 * '<S24>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check2'
 * '<S25>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check'
 * '<S26>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check1'
 * '<S27>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check2'
 * '<S28>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check3'
 * '<S29>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check4'
 * '<S30>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check5'
 * '<S31>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check6'
 * '<S32>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check7'
 * '<S33>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check8'
 * '<S34>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Scalar Signal Check'
 * '<S35>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Scalar Signal Check1'
 * '<S36>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Scalar Signal Check2'
 * '<S37>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Vector Signal Check'
 * '<S38>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Vector Signal Check1'
 * '<S39>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Vector Signal Check6'
 * '<S40>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/moorx'
 * '<S41>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/optimizer'
 * '<S42>'  : 'TV_ol/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/optimizer/FixedHorizonOptimizer'
 * '<S43>'  : 'TV_ol/Subsystem/Yaw rate reference calculation/MATLAB Function'
 */
#endif                                 /* RTW_HEADER_TV_ol_h_ */
