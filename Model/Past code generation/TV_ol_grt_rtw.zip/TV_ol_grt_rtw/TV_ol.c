/*
 * TV_ol.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TV_ol".
 *
 * Model version              : 3.15
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Sat Jan 13 17:12:32 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "TV_ol.h"
#include "rtwtypes.h"
#include <string.h>
#include <math.h>
#include "rt_nonfinite.h"
#include <emmintrin.h>
#include "TV_ol_private.h"

/* Named constants for MATLAB Function: '<S41>/FixedHorizonOptimizer' */
#define TV_ol_Wdu                      (0.010000000000000002)
#define TV_ol_Wu                       (0.0)
#define TV_ol_ny                       (3)
#define TV_ol_p                        (10)

/* Block signals (default storage) */
B_TV_ol_T TV_ol_B;

/* Block states (default storage) */
DW_TV_ol_T TV_ol_DW;

/* External inputs (root inport signals with default storage) */
ExtU_TV_ol_T TV_ol_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_TV_ol_T TV_ol_Y;

/* Real-time model */
static RT_MODEL_TV_ol_T TV_ol_M_;
RT_MODEL_TV_ol_T *const TV_ol_M = &TV_ol_M_;

/* Forward declaration for local functions */
static int32_T TV_ol_xpotrf(real_T b_A[4]);
static void TV_ol_trisolve(const real_T b_A[4], real_T b_B[4]);
static void TV_ol_mpcblock_optimizer(const real_T rseq[30], const real_T vseq[11],
  const real_T x[6], real_T old_u, boolean_T iA, const real_T b_utarget[10],
  real_T b_uoff, const real_T b_A[36], const real_T Bu[66], const real_T Bv[66],
  const real_T b_C[18], const real_T Dv[33], real_T *u, real_T useq[11], real_T *
  status, boolean_T *iAout);

/* Function for MATLAB Function: '<S41>/FixedHorizonOptimizer' */
static int32_T TV_ol_xpotrf(real_T b_A[4])
{
  int32_T b_k;
  int32_T info;
  int32_T jm1;
  boolean_T exitg1;
  info = 0;
  jm1 = 0;
  exitg1 = false;
  while ((!exitg1) && (jm1 < 2)) {
    real_T ssq;
    int32_T idxAjj;
    idxAjj = (jm1 << 1) + jm1;
    ssq = 0.0;
    if (jm1 >= 1) {
      for (b_k = 0; b_k < jm1; b_k++) {
        ssq += b_A[1] * b_A[1];
      }
    }

    ssq = b_A[idxAjj] - ssq;
    if (ssq > 0.0) {
      ssq = sqrt(ssq);
      b_A[idxAjj] = ssq;
      if (jm1 + 1 < 2) {
        int32_T scalarLB;
        int32_T vectorUB;
        ssq = 1.0 / ssq;
        scalarLB = idxAjj + 2;
        vectorUB = scalarLB - 2;
        for (b_k = idxAjj + 2; b_k <= vectorUB; b_k += 2) {
          __m128d tmp;
          tmp = _mm_loadu_pd(&b_A[b_k - 1]);
          tmp = _mm_mul_pd(tmp, _mm_set1_pd(ssq));
          _mm_storeu_pd(&b_A[b_k - 1], tmp);
        }

        for (b_k = scalarLB; b_k <= idxAjj + 2; b_k++) {
          b_A[b_k - 1] *= ssq;
        }
      }

      jm1++;
    } else {
      b_A[idxAjj] = ssq;
      info = jm1 + 1;
      exitg1 = true;
    }
  }

  return info;
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S41>/FixedHorizonOptimizer' */
static void TV_ol_trisolve(const real_T b_A[4], real_T b_B[4])
{
  int32_T b_k;
  int32_T i;
  int32_T j;
  for (j = 0; j < 2; j++) {
    int32_T jBcol;
    jBcol = j << 1;
    for (b_k = 0; b_k < 2; b_k++) {
      int32_T kAcol;
      kAcol = b_k << 1;
      if (b_B[b_k + jBcol] != 0.0) {
        b_B[b_k + jBcol] /= b_A[b_k + kAcol];
        for (i = b_k + 2; i < 3; i++) {
          b_B[jBcol + 1] -= b_B[b_k + jBcol] * b_A[kAcol + 1];
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<S41>/FixedHorizonOptimizer' */
static void TV_ol_mpcblock_optimizer(const real_T rseq[30], const real_T vseq[11],
  const real_T x[6], real_T old_u, boolean_T iA, const real_T b_utarget[10],
  real_T b_uoff, const real_T b_A[36], const real_T Bu[66], const real_T Bv[66],
  const real_T b_C[18], const real_T Dv[33], real_T *u, real_T useq[11], real_T *
  status, boolean_T *iAout)
{
  __m128d tmp;
  real_T c_Hv[330];
  real_T Su[300];
  real_T c_a[180];
  real_T WySuJm[60];
  real_T c_SuJm[60];
  real_T CA_0[33];
  real_T Sum_0[30];
  real_T b_a[30];
  real_T c_Kv[22];
  real_T I2Jm[20];
  real_T WduJm[20];
  real_T WuI2Jm[20];
  real_T CA[18];
  real_T CA_1[18];
  real_T c_Kx[12];
  real_T c[4];
  real_T c_Linv[4];
  real_T c_SuJm_0[4];
  real_T Sum[3];
  real_T b_C_0[3];
  real_T b_a_0[2];
  real_T c_Ku1[2];
  real_T f[2];
  real_T CA_2;
  real_T normH;
  real_T s;
  int32_T Tries;
  int32_T i;
  int32_T i1;
  int32_T i_0;
  int16_T ixw;
  int8_T a[100];
  int8_T rows[3];
  static const int8_T c_A[100] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1 };

  static const int8_T b_b[20] = { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0 };

  static const int8_T W[3] = { 1, 0, 0 };

  static const int8_T c_0[20] = { 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0 };

  boolean_T guard1;
  memset(&useq[0], 0, 11U * sizeof(real_T));
  *iAout = false;
  for (Tries = 0; Tries < 3; Tries++) {
    Sum[Tries] = 0.0;
    b_C_0[Tries] = 0.0;
    for (i1 = 0; i1 < 6; i1++) {
      normH = Sum[Tries];
      s = b_C_0[Tries];
      CA[Tries + 3 * i1] = 0.0;
      for (i_0 = 0; i_0 < 6; i_0++) {
        CA_2 = CA[3 * i1 + Tries];
        CA_2 += b_C[3 * i_0 + Tries] * b_A[6 * i1 + i_0];
        CA[Tries + 3 * i1] = CA_2;
      }

      normH += b_C[3 * i1 + Tries] * Bu[i1];
      s += b_C[3 * i1 + Tries] * Bv[i1];
      b_C_0[Tries] = s;
      Sum[Tries] = normH;
    }

    c_Hv[Tries] = b_C_0[Tries];
    c_Hv[Tries + 30] = Dv[Tries];
  }

  for (Tries = 0; Tries < 9; Tries++) {
    c_Hv[30 * (Tries + 2)] = 0.0;
    c_Hv[30 * (Tries + 2) + 1] = 0.0;
    c_Hv[30 * (Tries + 2) + 2] = 0.0;
  }

  for (Tries = 0; Tries < 11; Tries++) {
    memset(&c_Hv[Tries * 30 + 3], 0, 27U * sizeof(real_T));
  }

  for (Tries = 0; Tries < 6; Tries++) {
    c_a[30 * Tries] = CA[3 * Tries];
    c_a[30 * Tries + 1] = CA[3 * Tries + 1];
    c_a[30 * Tries + 2] = CA[3 * Tries + 2];
    memset(&c_a[Tries * 30 + 3], 0, 27U * sizeof(real_T));
  }

  b_a[0] = Sum[0];
  b_a[1] = Sum[1];
  b_a[2] = Sum[2];
  memset(&b_a[3], 0, 27U * sizeof(real_T));
  Su[0] = Sum[0];
  Su[1] = Sum[1];
  Su[2] = Sum[2];
  for (Tries = 0; Tries < 9; Tries++) {
    Su[30 * (Tries + 1)] = 0.0;
    Su[30 * (Tries + 1) + 1] = 0.0;
    Su[30 * (Tries + 1) + 2] = 0.0;
  }

  for (Tries = 0; Tries < 10; Tries++) {
    memset(&Su[Tries * 30 + 3], 0, 27U * sizeof(real_T));
  }

  for (i = 0; i < 9; i++) {
    int8_T kidx;
    kidx = (int8_T)((i + 1) * 3 + 1);
    for (Tries = 0; Tries < 3; Tries++) {
      int8_T rows_0;
      normH = Sum[Tries];
      rows_0 = (int8_T)(Tries + kidx);
      s = 0.0;
      for (i1 = 0; i1 < 6; i1++) {
        s += CA[3 * i1 + Tries] * Bu[i1];
      }

      normH += s;
      b_a[rows_0 - 1] = normH;
      Sum_0[Tries] = normH;
      Sum[Tries] = normH;
      rows[Tries] = rows_0;
    }

    for (Tries = 0; Tries < 9; Tries++) {
      Sum_0[3 * (Tries + 1)] = Su[(30 * Tries + rows[0]) - 4];
      Sum_0[3 * (Tries + 1) + 1] = Su[(30 * Tries + rows[1]) - 4];
      Sum_0[3 * (Tries + 1) + 2] = Su[(30 * Tries + rows[2]) - 4];
    }

    for (Tries = 0; Tries < 10; Tries++) {
      Su[(rows[0] + 30 * Tries) - 1] = Sum_0[3 * Tries];
      Su[(rows[1] + 30 * Tries) - 1] = Sum_0[3 * Tries + 1];
      Su[(rows[2] + 30 * Tries) - 1] = Sum_0[3 * Tries + 2];
    }

    for (Tries = 0; Tries < 3; Tries++) {
      b_C_0[Tries] = 0.0;
      for (i1 = 0; i1 < 6; i1++) {
        CA_2 = b_C_0[Tries];
        CA_2 += CA[3 * i1 + Tries] * Bv[i1];
        b_C_0[Tries] = CA_2;
      }

      CA_0[Tries] = b_C_0[Tries];
    }

    for (Tries = 0; Tries < 10; Tries++) {
      CA_0[3 * (Tries + 1)] = c_Hv[(30 * Tries + rows[0]) - 4];
      CA_0[3 * (Tries + 1) + 1] = c_Hv[(30 * Tries + rows[1]) - 4];
      CA_0[3 * (Tries + 1) + 2] = c_Hv[(30 * Tries + rows[2]) - 4];
    }

    for (Tries = 0; Tries < 11; Tries++) {
      c_Hv[(rows[0] + 30 * Tries) - 1] = CA_0[3 * Tries];
      c_Hv[(rows[1] + 30 * Tries) - 1] = CA_0[3 * Tries + 1];
      c_Hv[(rows[2] + 30 * Tries) - 1] = CA_0[3 * Tries + 2];
    }

    for (Tries = 0; Tries < 3; Tries++) {
      for (i1 = 0; i1 < 6; i1++) {
        CA_1[Tries + 3 * i1] = 0.0;
        for (i_0 = 0; i_0 < 6; i_0++) {
          CA_2 = CA_1[3 * i1 + Tries];
          CA_2 += CA[3 * i_0 + Tries] * b_A[6 * i1 + i_0];
          CA_1[Tries + 3 * i1] = CA_2;
        }
      }
    }

    memcpy(&CA[0], &CA_1[0], 18U * sizeof(real_T));
    for (Tries = 0; Tries < 6; Tries++) {
      c_a[(rows[0] + 30 * Tries) - 1] = CA[3 * Tries];
      c_a[(rows[1] + 30 * Tries) - 1] = CA[3 * Tries + 1];
      c_a[(rows[2] + 30 * Tries) - 1] = CA[3 * Tries + 2];
    }
  }

  for (Tries = 0; Tries < 2; Tries++) {
    for (i1 = 0; i1 < 30; i1++) {
      c_SuJm[i1 + 30 * Tries] = 0.0;
      for (i_0 = 0; i_0 < 10; i_0++) {
        normH = c_SuJm[30 * Tries + i1];
        normH += Su[30 * i_0 + i1] * (real_T)b_b[10 * Tries + i_0];
        c_SuJm[i1 + 30 * Tries] = normH;
      }
    }
  }

  i = -1;
  for (Tries = 0; Tries < 10; Tries++) {
    for (i1 = 0; i1 < 10; i1++) {
      a[(i + i1) + 1] = c_A[10 * Tries + i1];
    }

    i += 10;
  }

  for (Tries = 0; Tries < 2; Tries++) {
    for (i1 = 0; i1 < 10; i1++) {
      I2Jm[i1 + 10 * Tries] = 0.0;
      for (i_0 = 0; i_0 < 10; i_0++) {
        normH = I2Jm[10 * Tries + i1];
        normH += (real_T)(a[10 * i_0 + i1] * b_b[10 * Tries + i_0]);
        I2Jm[i1 + 10 * Tries] = normH;
      }
    }
  }

  ixw = 1;
  for (i = 0; i < 30; i++) {
    Tries = W[ixw - 1];
    WySuJm[i] = (real_T)Tries * c_SuJm[i];
    WySuJm[i + 30] = c_SuJm[i + 30] * (real_T)Tries;
    ixw++;
    if (ixw > 3) {
      ixw = 1;
    }
  }

  for (i = 0; i < 10; i++) {
    WuI2Jm[i] = TV_ol_Wu * I2Jm[i];
    WduJm[i] = TV_ol_Wdu * (real_T)b_b[i];
    WuI2Jm[i + 10] = I2Jm[i + 10] * TV_ol_Wu;
    WduJm[i + 10] = (real_T)b_b[i + 10] * TV_ol_Wdu;
  }

  for (Tries = 0; Tries < 2; Tries++) {
    for (i1 = 0; i1 < 2; i1++) {
      c_SuJm_0[Tries + (i1 << 1)] = 0.0;
      for (i_0 = 0; i_0 < 30; i_0++) {
        normH = c_SuJm_0[(i1 << 1) + Tries];
        normH += c_SuJm[30 * Tries + i_0] * WySuJm[30 * i1 + i_0];
        c_SuJm_0[Tries + (i1 << 1)] = normH;
      }

      c[Tries + (i1 << 1)] = 0.0;
      s = 0.0;
      for (i_0 = 0; i_0 < 10; i_0++) {
        normH = c[(i1 << 1) + Tries];
        normH += (real_T)c_0[(i_0 << 1) + Tries] * WduJm[10 * i1 + i_0];
        s += I2Jm[10 * Tries + i_0] * WuI2Jm[10 * i1 + i_0];
        c[Tries + (i1 << 1)] = normH;
      }

      c_Linv[Tries + (i1 << 1)] = (c_SuJm_0[(i1 << 1) + Tries] + c[(i1 << 1) +
        Tries]) + s;
    }

    b_a_0[Tries] = 0.0;
    for (i1 = 0; i1 < 30; i1++) {
      normH = b_a_0[Tries];
      normH += WySuJm[30 * Tries + i1] * b_a[i1];
      b_a_0[Tries] = normH;
    }

    f[Tries] = 0.0;
    for (i1 = 0; i1 < 10; i1++) {
      s = f[Tries];
      s += WuI2Jm[10 * Tries + i1];
      f[Tries] = s;
    }

    c_Ku1[Tries] = b_a_0[Tries] + f[Tries];
  }

  for (Tries = 0; Tries <= 18; Tries += 2) {
    tmp = _mm_loadu_pd(&WuI2Jm[Tries]);
    tmp = _mm_mul_pd(tmp, _mm_set1_pd(-1.0));
    _mm_storeu_pd(&WuI2Jm[Tries], tmp);
  }

  for (Tries = 0; Tries < 6; Tries++) {
    for (i1 = 0; i1 < 2; i1++) {
      c_Kx[Tries + 6 * i1] = 0.0;
      for (i_0 = 0; i_0 < 30; i_0++) {
        normH = c_Kx[6 * i1 + Tries];
        normH += c_a[30 * Tries + i_0] * WySuJm[30 * i1 + i_0];
        c_Kx[Tries + 6 * i1] = normH;
      }
    }
  }

  for (Tries = 0; Tries < 11; Tries++) {
    for (i1 = 0; i1 < 2; i1++) {
      c_Kv[Tries + 11 * i1] = 0.0;
      for (i_0 = 0; i_0 < 30; i_0++) {
        s = c_Kv[11 * i1 + Tries];
        s += c_Hv[30 * Tries + i_0] * WySuJm[30 * i1 + i_0];
        c_Kv[Tries + 11 * i1] = s;
      }
    }
  }

  for (Tries = 0; Tries <= 58; Tries += 2) {
    tmp = _mm_loadu_pd(&WySuJm[Tries]);
    tmp = _mm_mul_pd(tmp, _mm_set1_pd(-1.0));
    _mm_storeu_pd(&WySuJm[Tries], tmp);
  }

  i = 0;
  c_SuJm_0[0] = c_Linv[0];
  c_SuJm_0[1] = c_Linv[1];
  c_SuJm_0[2] = c_Linv[2];
  c_SuJm_0[3] = c_Linv[3];
  Tries = TV_ol_xpotrf(c_SuJm_0);
  guard1 = false;
  if (Tries == 0) {
    b_a_0[0] = c_SuJm_0[0];
    b_a_0[1] = c_SuJm_0[3];
    if ((b_a_0[0] > b_a_0[1]) || (rtIsNaN(b_a_0[0]) && (!rtIsNaN(b_a_0[1])))) {
      normH = b_a_0[1];
    } else {
      normH = b_a_0[0];
    }

    if (normH > 1.4901161193847656E-7) {
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    boolean_T exitg2;
    normH = 0.0;
    Tries = 0;
    exitg2 = false;
    while ((!exitg2) && (Tries < 2)) {
      s = fabs(c_Linv[Tries]);
      s += fabs(c_Linv[Tries + 2]);
      if (rtIsNaN(s)) {
        normH = (rtNaN);
        exitg2 = true;
      } else {
        if (s > normH) {
          normH = s;
        }

        Tries++;
      }
    }

    if (normH >= 1.0E+10) {
      i = 2;
    } else {
      boolean_T exitg1;
      Tries = 0;
      exitg1 = false;
      while ((!exitg1) && (Tries <= 4)) {
        boolean_T guard2;
        normH = rt_powd_snf(10.0, (real_T)Tries) * 1.4901161193847656E-7;
        c_Linv[0] += normH;
        c_SuJm_0[0] = c_Linv[0];
        c_SuJm_0[1] = c_Linv[1];
        c_SuJm_0[2] = c_Linv[2];
        c_Linv[3] += normH;
        c_SuJm_0[3] = c_Linv[3];
        i = TV_ol_xpotrf(c_SuJm_0);
        guard2 = false;
        if (i == 0) {
          b_a_0[0] = c_SuJm_0[0];
          b_a_0[1] = c_SuJm_0[3];
          if ((b_a_0[0] > b_a_0[1]) || (rtIsNaN(b_a_0[0]) && (!rtIsNaN(b_a_0[1]))))
          {
            normH = b_a_0[1];
          } else {
            normH = b_a_0[0];
          }

          if (normH > 1.4901161193847656E-7) {
            i = 1;
            exitg1 = true;
          } else {
            guard2 = true;
          }
        } else {
          guard2 = true;
        }

        if (guard2) {
          i = 3;
          Tries++;
        }
      }
    }
  }

  if (i > 1) {
    *u = old_u + b_uoff;
    for (i = 0; i < 11; i++) {
      useq[i] = *u;
    }

    *status = -2.0;
  } else {
    c_Linv[0] = 1.0;
    c_Linv[1] = 0.0;
    c_Linv[2] = 0.0;
    c_Linv[3] = 1.0;
    TV_ol_trisolve(c_SuJm_0, c_Linv);
    *iAout = iA;
    for (i = 0; i < 2; i++) {
      real_T WuI2Jm_0;
      c_SuJm_0[i] = 0.0;
      normH = c_SuJm_0[i];
      normH += c_Linv[i << 1] * c_Linv[0];
      c_SuJm_0[i] = normH;
      normH = c_SuJm_0[i];
      normH += c_Linv[(i << 1) + 1] * c_Linv[1];
      c_SuJm_0[i] = normH;
      c_SuJm_0[i + 2] = 0.0;
      normH = c_SuJm_0[i + 2];
      normH += c_Linv[i << 1] * c_Linv[2];
      c_SuJm_0[i + 2] = normH;
      normH = c_SuJm_0[i + 2];
      normH += c_Linv[(i << 1) + 1] * c_Linv[3];
      c_SuJm_0[i + 2] = normH;
      normH = 0.0;
      for (Tries = 0; Tries < 6; Tries++) {
        normH += c_Kx[6 * i + Tries] * x[Tries];
      }

      CA_2 = 0.0;
      for (Tries = 0; Tries < 30; Tries++) {
        CA_2 += WySuJm[30 * i + Tries] * rseq[Tries];
      }

      s = 0.0;
      for (Tries = 0; Tries < 11; Tries++) {
        s += c_Kv[11 * i + Tries] * vseq[Tries];
      }

      WuI2Jm_0 = 0.0;
      for (Tries = 0; Tries < 10; Tries++) {
        WuI2Jm_0 += WuI2Jm[10 * i + Tries] * b_utarget[Tries];
      }

      f[i] = (((normH + CA_2) + c_Ku1[i] * old_u) + s) + WuI2Jm_0;
      b_a_0[i] = 0.0;
    }

    normH = b_a_0[0];
    normH -= c_SuJm_0[0] * f[0];
    b_a_0[0] = normH;
    normH = b_a_0[0];
    normH -= f[1] * c_SuJm_0[2];
    b_a_0[0] = normH;
    *status = 1.0;
    *u = (old_u + b_a_0[0]) + b_uoff;
  }
}

/* Model step function */
void TV_ol_step(void)
{
  real_T Cm[198];
  real_T CovMat[81];
  real_T Bu[66];
  real_T Bv[66];
  real_T b_tmp[63];
  real_T b_B[48];
  real_T b_A[36];
  real_T b_A_0[36];
  real_T b_A_2[36];
  real_T b_A_3[36];
  real_T Dv[33];
  real_T rseq[30];
  real_T L[18];
  real_T b_A_1[18];
  real_T b_C[18];
  real_T tmp[18];
  real_T vseq[11];
  real_T b_utarget[10];
  real_T Kinv[9];
  real_T c_A[9];
  real_T b_xoff[6];
  real_T xk[6];
  real_T Y[3];
  real_T y_innov[3];
  real_T L_0;
  real_T a21;
  real_T b_A_4;
  real_T b_A_5;
  real_T maxval;
  int32_T i;
  int32_T r2;
  int32_T r3;
  int8_T c_B[9];
  int8_T UnknownIn[7];
  boolean_T iAout;
  static const real_T c[36] = { -6.4285714285714288, 0.0, 0.0, 0.0, 0.0, 0.0,
    -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.2142857142857144, 4.9178571428571427, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 1.0 };

  static const real_T d[48] = { 0.0, 0.0071428571428571426, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.001, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.001, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.001, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

  static const int8_T e[18] = { 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0,
    0, 1 };

  static const int8_T b_D[24] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 1, 0, 0, 0, 1 };

  /* DeadZone: '<S3>/Dead Zone' incorporates:
   *  Inport: '<Root>/StrAngleDeg'
   */
  if (TV_ol_U.StrAngleDeg > TV_ol_P.SteeringDeadzonelimit) {
    /* DeadZone: '<S3>/Dead Zone' */
    TV_ol_B.DeadZone = TV_ol_U.StrAngleDeg - TV_ol_P.SteeringDeadzonelimit;
  } else {
    a21 = -TV_ol_P.SteeringDeadzonelimit;
    if (TV_ol_U.StrAngleDeg >= a21) {
      /* DeadZone: '<S3>/Dead Zone' */
      TV_ol_B.DeadZone = 0.0;
    } else {
      a21 = -TV_ol_P.SteeringDeadzonelimit;

      /* DeadZone: '<S3>/Dead Zone' */
      TV_ol_B.DeadZone = TV_ol_U.StrAngleDeg - a21;
    }
  }

  /* End of DeadZone: '<S3>/Dead Zone' */

  /* Abs: '<S3>/Abs' */
  TV_ol_B.Abs = fabs(TV_ol_B.DeadZone);

  /* Signum: '<S3>/Sign' */
  maxval = TV_ol_B.Abs;
  if (rtIsNaN(maxval)) {
    /* Signum: '<S3>/Sign' */
    TV_ol_B.Sign = (rtNaN);
  } else if (maxval < 0.0) {
    /* Signum: '<S3>/Sign' */
    TV_ol_B.Sign = -1.0;
  } else {
    /* Signum: '<S3>/Sign' */
    TV_ol_B.Sign = (maxval > 0.0);
  }

  /* End of Signum: '<S3>/Sign' */

  /* RelationalOperator: '<S2>/Compare' incorporates:
   *  Constant: '<S2>/Constant'
   *  Inport: '<Root>/VehicleSpeed'
   */
  TV_ol_B.Compare = (TV_ol_U.VehicleSpeed >= TV_ol_P.CompareToConstant_const);

  /* Logic: '<S1>/AND' incorporates:
   *  Inport: '<Root>/TorqueVectoringEnabled'
   */
  TV_ol_B.TVactivation = ((TV_ol_B.Sign != 0.0) && TV_ol_B.Compare &&
    (TV_ol_U.TorqueVectoringEnabled != 0.0));

  /* Logic: '<S8>/AND' incorporates:
   *  Inport: '<Root>/FeedbackEnabled'
   */
  TV_ol_B.AND = (TV_ol_U.FeedbackEnabled && TV_ol_B.TVactivation);
  for (i = 0; i < 6; i++) {
    /* Memory: '<S13>/last_x' */
    TV_ol_B.last_x[i] = TV_ol_DW.last_x_PreviousInput[i];
  }

  /* UnitDelay: '<S13>/last_mv' */
  TV_ol_B.last_mv = TV_ol_DW.last_mv_DSTATE;

  /* SignalConversion generated from: '<S10>/Vector Concatenate' incorporates:
   *  Concatenate: '<S10>/Vector Concatenate'
   *  Inport: '<Root>/LateralVelocity'
   */
  TV_ol_B.VectorConcatenate[0] = TV_ol_U.LateralVelocity;

  /* SignalConversion generated from: '<S10>/Vector Concatenate' incorporates:
   *  Concatenate: '<S10>/Vector Concatenate'
   *  Inport: '<Root>/VehicleYawRate'
   */
  TV_ol_B.VectorConcatenate[1] = TV_ol_U.VehicleYawRate;

  /* SignalConversion generated from: '<S10>/Vector Concatenate' incorporates:
   *  Concatenate: '<S10>/Vector Concatenate'
   *  Inport: '<Root>/StrAngleDeg'
   */
  TV_ol_B.VectorConcatenate[2] = TV_ol_U.StrAngleDeg;

  /* SignalConversion generated from: '<S10>/Vector Concatenate1' incorporates:
   *  Concatenate: '<S10>/Vector Concatenate1'
   *  Inport: '<Root>/LateralVelocity'
   */
  TV_ol_B.VectorConcatenate1[0] = TV_ol_U.LateralVelocity;

  /* Gain: '<S6>/Gain1' */
  a21 = 1.0 / TV_ol_P.Sgr;

  /* Gain: '<S6>/Gain1' incorporates:
   *  Inport: '<Root>/StrAngleDeg'
   */
  TV_ol_B.Steeringangleatwheelsdegs = a21 * TV_ol_U.StrAngleDeg;

  /* Fcn: '<S6>/Fcn2' incorporates:
   *  Inport: '<Root>/VehicleSpeed'
   */
  TV_ol_B.Fcn2 = ((real_T)(TV_ol_U.VehicleSpeed == 0.0) + TV_ol_U.VehicleSpeed)
    + 2.2204460492503131e-16;

  /* Product: '<S6>/Product' */
  TV_ol_B.Product = TV_ol_B.Steeringangleatwheelsdegs * TV_ol_B.Fcn2;

  /* Math: '<S6>/Square' */
  TV_ol_B.Square = TV_ol_B.Fcn2 * TV_ol_B.Fcn2;

  /* Gain: '<S6>/Gain' */
  TV_ol_B.Gain = TV_ol_P.Ku * TV_ol_B.Square;

  /* Sum: '<S6>/Plus' incorporates:
   *  Constant: '<S6>/Constant'
   */
  TV_ol_B.Plus = TV_ol_P.l + TV_ol_B.Gain;

  /* Product: '<S6>/Divide' */
  TV_ol_B.Desiredyawratereferencedegs = TV_ol_B.Product / TV_ol_B.Plus;

  /* Product: '<S6>/Product1' incorporates:
   *  Constant: '<S6>/Constant1'
   *  Constant: '<S6>/Constant2'
   */
  TV_ol_B.Product1 = TV_ol_P.myy * TV_ol_P.g;

  /* Product: '<S6>/Divide1' */
  TV_ol_B.Upperlimitrads = 1.0 / TV_ol_B.Fcn2 * TV_ol_B.Product1;

  /* Gain: '<S6>/Gain2' */
  TV_ol_B.Gain2 = TV_ol_P.Gain2_Gain * TV_ol_B.Upperlimitrads;

  /* MATLAB Function: '<S6>/MATLAB Function' incorporates:
   *  Concatenate: '<S10>/Vector Concatenate1'
   */
  /* :  if abs(yaw_rate_reference_original) < yaw_rate_limit */
  if (fabs(TV_ol_B.Desiredyawratereferencedegs) < TV_ol_B.Gain2) {
    /* :  yaw_rate_reference = yaw_rate_reference_original ; */
    TV_ol_B.VectorConcatenate1[1] = TV_ol_B.Desiredyawratereferencedegs;
  } else {
    /* :  else */
    /* :  yaw_rate_reference = yaw_rate_limit*sign(yaw_rate_reference_original) ; */
    maxval = TV_ol_B.Desiredyawratereferencedegs;
    if (rtIsNaN(maxval)) {
      maxval = (rtNaN);
    } else if (maxval < 0.0) {
      maxval = -1.0;
    } else {
      maxval = (maxval > 0.0);
    }

    TV_ol_B.VectorConcatenate1[1] = TV_ol_B.Gain2 * maxval;
  }

  /* End of MATLAB Function: '<S6>/MATLAB Function' */

  /* SignalConversion generated from: '<S10>/Vector Concatenate1' incorporates:
   *  Concatenate: '<S10>/Vector Concatenate1'
   *  Inport: '<Root>/StrAngleDeg'
   */
  TV_ol_B.VectorConcatenate1[2] = TV_ol_U.StrAngleDeg;

  /* Gain: '<S13>/umin_scale4' incorporates:
   *  Constant: '<S11>/E_zero'
   */
  TV_ol_B.umin_scale4 = TV_ol_P.umin_scale4_Gain * TV_ol_P.E_zero_Value;

  /* Gain: '<S13>/ymin_scale2' incorporates:
   *  Constant: '<S11>/S_zero'
   */
  TV_ol_B.ymin_scale2 = TV_ol_P.ymin_scale2_Gain * TV_ol_P.S_zero_Value;

  /* Gain: '<S13>/ext.mv_scale' incorporates:
   *  Constant: '<S11>/ext.mv_zero'
   */
  TV_ol_B.extmv_scale = TV_ol_P.extmv_scale_Gain * TV_ol_P.extmv_zero_Value;

  /* Gain: '<S13>/uref_scale' incorporates:
   *  Constant: '<S11>/mv.target_zero'
   */
  TV_ol_B.uref_scale = TV_ol_P.uref_scale_Gain * TV_ol_P.mvtarget_zero_Value;

  /* Math: '<S13>/Math Function1' incorporates:
   *  Constant: '<S11>/u.wt_zero'
   */
  TV_ol_B.MathFunction1 = TV_ol_P.uwt_zero_Value;

  /* Math: '<S13>/Math Function2' incorporates:
   *  Constant: '<S11>/du.wt_zero'
   */
  TV_ol_B.MathFunction2 = TV_ol_P.duwt_zero_Value;

  /* MATLAB Function: '<S10>/MATLAB Function' incorporates:
   *  Inport: '<Root>/VehicleSpeed'
   */
  /* :  Cr = 1 */
  /* :  Cf = 1 */
  /* :  m = 200 */
  /* :  Izz = 100 */
  /* :  lf = 0.7650 */
  /* :  lr = 0.7650 */
  /* :  A = [-(Cr + Cf)/(m), (-v_x^2*m-Cf*lf + Cr*lr)/(m),Cf/m; (lr*Cr-lf*Cf)/(Izz), (lf^2*Cf-lr^2*Cr)/(Izz),lf*Cf/Izz;0,0,0]; */
  TV_ol_B.A[0] = -0.01;
  TV_ol_B.A[3] = ((-(TV_ol_U.VehicleSpeed * TV_ol_U.VehicleSpeed) * 200.0 -
                   0.765) + 0.765) / 200.0;
  TV_ol_B.A[6] = 0.005;

  /* Gain: '<S13>/ymin_scale1' incorporates:
   *  Constant: '<S11>/F_zero'
   */
  TV_ol_B.ymin_scale1[0] = TV_ol_P.ymin_scale1_Gain[0] * TV_ol_P.F_zero_Value[0];

  /* Math: '<S13>/Math Function' incorporates:
   *  Constant: '<S11>/y.wt_zero'
   */
  TV_ol_B.MathFunction[0] = TV_ol_P.ywt_zero_Value[0];

  /* MATLAB Function: '<S10>/MATLAB Function' */
  TV_ol_B.B[0] = 0.0;
  TV_ol_B.A[1] = 0.0;
  TV_ol_B.A[2] = 0.0;

  /* Gain: '<S13>/ymin_scale1' incorporates:
   *  Constant: '<S11>/F_zero'
   */
  TV_ol_B.ymin_scale1[1] = TV_ol_P.ymin_scale1_Gain[1] * TV_ol_P.F_zero_Value[1];

  /* Math: '<S13>/Math Function' incorporates:
   *  Constant: '<S11>/y.wt_zero'
   */
  TV_ol_B.MathFunction[1] = TV_ol_P.ywt_zero_Value[1];

  /* MATLAB Function: '<S10>/MATLAB Function' */
  TV_ol_B.B[1] = 0.01;
  TV_ol_B.A[4] = 0.0;
  TV_ol_B.A[5] = 0.0;

  /* Gain: '<S13>/ymin_scale1' incorporates:
   *  Constant: '<S11>/F_zero'
   */
  TV_ol_B.ymin_scale1[2] = TV_ol_P.ymin_scale1_Gain[2] * TV_ol_P.F_zero_Value[2];

  /* Math: '<S13>/Math Function' incorporates:
   *  Constant: '<S11>/y.wt_zero'
   */
  TV_ol_B.MathFunction[2] = TV_ol_P.ywt_zero_Value[2];

  /* MATLAB Function: '<S10>/MATLAB Function' incorporates:
   *  Inport: '<Root>/LateralVelocity'
   *  Inport: '<Root>/StrAngleDeg'
   *  Inport: '<Root>/VehicleYawRate'
   */
  TV_ol_B.B[2] = 0.0;
  TV_ol_B.A[7] = 0.0076500000000000005;
  TV_ol_B.A[8] = 0.0;

  /* :  B = [0; 1/Izz;0]; */
  /* :  C = eye(3); */
  memset(&TV_ol_B.C[0], 0, 9U * sizeof(real_T));

  /* :  D = zeros([3,1]); */
  /* :  X = [v_y;yr;str]; */
  TV_ol_B.X[0] = TV_ol_U.LateralVelocity;
  TV_ol_B.X[1] = TV_ol_U.VehicleYawRate;
  TV_ol_B.X[2] = TV_ol_U.StrAngleDeg;

  /* :  Y = [v_y;yr;str]; */
  TV_ol_B.Y[0] = TV_ol_U.LateralVelocity;
  TV_ol_B.Y[1] = TV_ol_U.VehicleYawRate;
  TV_ol_B.Y[2] = TV_ol_U.StrAngleDeg;

  /* :  U = [0]; */
  TV_ol_B.U = 0.0;

  /* :  DX = A*X; */
  for (i = 0; i < 3; i++) {
    TV_ol_B.C[i + 3 * i] = 1.0;
    TV_ol_B.D[i] = 0.0;
    b_A_4 = TV_ol_B.A[i] * TV_ol_B.X[0];
    b_A_4 += TV_ol_B.A[i + 3] * TV_ol_B.X[1];
    b_A_4 += TV_ol_B.A[i + 6] * TV_ol_B.X[2];
    TV_ol_B.DX[i] = b_A_4;
  }

  /* Memory: '<S13>/LastPcov' */
  memcpy(&TV_ol_B.LastPcov[0], &TV_ol_DW.LastPcov_PreviousInput[0], 36U * sizeof
         (real_T));

  /* Memory: '<S13>/Memory' */
  TV_ol_B.Memory = TV_ol_DW.Memory_PreviousInput;

  /* MATLAB Function: '<S41>/FixedHorizonOptimizer' incorporates:
   *  Memory: '<S13>/LastPcov'
   */
  /* :  coder.extrinsic('mpcblock_optimizer_double_mex'); */
  /* :  coder.extrinsic('mpcblock_optimizer_single_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_double_mex'); */
  /* :  coder.extrinsic('mpcblock_refmd_single_mex'); */
  /* :  xk = convertDataType(xk0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  old_u = convertDataType(old_u0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  ym = convertDataType(ym0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  ref = convertDataType(ref0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  md = convertDataType(md0,isDouble); */
  /* :  umin = convertDataType(umin0,isDouble); */
  /* :  umax = convertDataType(umax0,isDouble); */
  /* :  ymin = convertDataType(ymin0,isDouble); */
  /* :  ymax = convertDataType(ymax0,isDouble); */
  /* :  E = convertDataType(E0,isDouble); */
  /* :  F = convertDataType(F0,isDouble); */
  /* :  G = convertDataType(G0,isDouble); */
  /* :  S = convertDataType(S0,isDouble); */
  /* :  switch_in = int32(switch_in0); */
  /* :  ext_mv = convertDataType(ext_mv0,isDouble); */
  /* :  MVtarget = convertDataType(MVtarget0,isDouble); */
  /* :  ywt = convertDataType(ywt0,isDouble); */
  /* :  uwt = convertDataType(uwt0,isDouble); */
  /* :  duwt = convertDataType(duwt0,isDouble); */
  /* :  ewt = convertDataType(ewt0,isDouble); */
  /* :  a = convertDataType(a0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  b = convertDataType(b0,isDouble); */
  Y[0] = 0.0;
  Y[1] = 0.01;
  Y[2] = 0.0;

  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  c = convertDataType(c0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  d = convertDataType(d0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  U = convertDataType(U0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  Y = convertDataType(Y0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  X = convertDataType(X0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  DX = convertDataType(DX0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  Pk = convertDataType(Pk0,isDouble); */
  /* :  if isDouble */
  /* :  if isa(u,'double') */
  /* :  y = u; */
  /* :  isSimulation = coder.target('Sfun') && ~coder.target('RtwForRapid') && ~coder.target('RtwForSim'); */
  /* :  isAdaptive = ~isLTV; */
  /* :  ZERO = zeros('like',ref); */
  /* :  ONE = ones('like',ref); */
  /* :  hasMD = nv>int32(1); */
  /* :  if isSimulation */
  /* :  nym = int32(length(myindex)); */
  /* :  ai=zeros(nxp,nxp,'like',ref); */
  /* :  bi=zeros(nxp,nup,'like',ref); */
  /* :  ci=zeros(ny,nxp,'like',ref); */
  /* :  di=zeros(ny,nup,'like',ref); */
  /* :  ai(:,:)=a(:,:,1); */
  /* :  bi(:,:)=b(:,:,1); */
  /* :  ci(:,:)=c(:,:,1); */
  /* :  di(:,:)=d(:,:,1); */
  /* :  Bu=zeros(nx,nu,p+1,'like',ref); */
  /* :  Bv=zeros(nx,nv,p+1,'like',ref); */
  memset(&Bu[0], 0, 66U * sizeof(real_T));
  memset(&Bv[0], 0, 66U * sizeof(real_T));

  /* :  Dv=zeros(ny,nv,p+1,'like',ref); */
  /* :  Dvm=zeros(nym,nv,p+1,'like',ref); */
  memset(&Dv[0], 0, 33U * sizeof(real_T));

  /* :  Cm=zeros(nym,nx,p+1,'like',ref); */
  memset(&Cm[0], 0, 198U * sizeof(real_T));

  /* :  [A(:,:,1),C(:,:,1),Bu(:,:,1),Bv(:,:,1),Cm(:,:,1),Dv(:,:,1),Dvm(:,:,1),Qk,Rk,Nk] = mpc_plantupdate(... */
  /* :      ai,bi,ci,di,A(:,:,1),B(:,:,1),C(:,:,1),D(:,:,1),mvindex,mdindex,unindex,nxp,nup,ny,nu,nv,nxid, ... */
  /* :      myindex,Uscale,Yscale,Cid,Did); */
  memcpy(&b_A[0], &c[0], 36U * sizeof(real_T));
  memcpy(&b_B[0], &d[0], 48U * sizeof(real_T));
  for (r2 = 0; r2 < 18; r2++) {
    b_C[r2] = e[r2];
  }

  for (r2 = 0; r2 < 3; r2++) {
    b_B[r2] = Y[r2];
    b_C[3 * r2] = TV_ol_B.C[3 * r2];
    b_A[6 * r2] = TV_ol_B.A[3 * r2];
    b_C[3 * r2 + 1] = TV_ol_B.C[3 * r2 + 1];
    b_A[6 * r2 + 1] = TV_ol_B.A[3 * r2 + 1];
    b_C[3 * r2 + 2] = TV_ol_B.C[3 * r2 + 2];
    b_A[6 * r2 + 2] = TV_ol_B.A[3 * r2 + 2];
  }

  for (r2 = 0; r2 < 6; r2++) {
    Bu[r2] = b_B[r2];
    Bv[r2] = b_B[r2 + 6];
    Cm[3 * r2] = b_C[3 * r2];
    Cm[3 * r2 + 1] = b_C[3 * r2 + 1];
    Cm[3 * r2 + 2] = b_C[3 * r2 + 2];
  }

  for (r2 = 0; r2 < 7; r2++) {
    UnknownIn[r2] = 0;
  }

  UnknownIn[0] = 1;
  for (r2 = 0; r2 < 6; r2++) {
    UnknownIn[r2 + 1] = (int8_T)(r2 + 3);
  }

  for (r2 = 0; r2 < 7; r2++) {
    for (r3 = 0; r3 < 6; r3++) {
      b_tmp[r3 + 9 * r2] = b_B[(UnknownIn[r2] - 1) * 6 + r3];
    }

    b_tmp[9 * r2 + 6] = b_D[(UnknownIn[r2] - 1) * 3];
    b_tmp[9 * r2 + 7] = b_D[(UnknownIn[r2] - 1) * 3 + 1];
    b_tmp[9 * r2 + 8] = b_D[(UnknownIn[r2] - 1) * 3 + 2];
  }

  for (r2 = 0; r2 < 9; r2++) {
    for (r3 = 0; r3 < 9; r3++) {
      CovMat[r2 + 9 * r3] = 0.0;
      for (i = 0; i < 7; i++) {
        maxval = CovMat[9 * r3 + r2];
        maxval += b_tmp[9 * i + r2] * b_tmp[9 * i + r3];
        CovMat[r2 + 9 * r3] = maxval;
      }
    }
  }

  Dv[0] = 0.0;
  Dv[1] = 0.0;
  Dv[2] = 0.0;

  /* :  if isLTV */
  /* :  [Mlim, utarget, uoff, voff, yoff, myoff, xoff, Bv, Dv] = ... */
  /* :      mpc_updateFromNominal(isAdaptive,isQP,Mlim,Mrows,... */
  /* :         U,Uscale,uoff,mvindex,voff,mdindex,utarget,nu,nv-1,... */
  /* :         Y,Yscale,yoff,myoff,myindex,ny,... */
  /* :         X,xoff,nxp,DX,A,Bu,Bv,C,Dv,nCC); */
  for (i = 0; i < 6; i++) {
    b_xoff[i] = 0.0;
  }

  Y[0] = TV_ol_B.Y[0];
  Y[1] = TV_ol_B.Y[1];
  Y[2] = TV_ol_B.Y[2];
  memset(&b_utarget[0], 0, 10U * sizeof(real_T));
  b_xoff[0] = TV_ol_B.X[0];
  Bv[0] = TV_ol_B.DX[0];
  b_xoff[1] = TV_ol_B.X[1];
  Bv[1] = TV_ol_B.DX[1];
  b_xoff[2] = TV_ol_B.X[2];
  Bv[2] = TV_ol_B.DX[2];

  /* :  old_u = old_u - uoff; */
  /* :  if isSimulation */
  /* :  else */
  /* :  [rseq, vseq, v] = mpcblock_refmd(ref,md,nv,ny,p,yoff,voff,no_md,no_ref,openloopflag, RYscale, RMDscale); */
  for (i = 0; i < 11; i++) {
    vseq[i] = 1.0;
  }

  for (i = 0; i < 10; i++) {
    rseq[i * TV_ol_ny] = TV_ol_B.VectorConcatenate1[0] - Y[0];
    rseq[i * TV_ol_ny + 1] = TV_ol_B.VectorConcatenate1[1] - Y[1];
    rseq[i * TV_ol_ny + 2] = TV_ol_B.VectorConcatenate1[2] - Y[2];
  }

  /* :  if no_mv */
  /* :  delmv = zeros(nu,1,'like',ref); */
  /* :  xk = xk - xoff; */
  /* :  if CustomEstimation */
  /* :  else */
  /* :  Kinv = eye(nym,'like',ref)/(Cm(:,:,1)*Pk*Cm(:,:,1)' + Rk); */
  for (r2 = 0; r2 < 9; r2++) {
    c_B[r2] = 0;
  }

  for (i = 0; i < 3; i++) {
    c_B[i + 3 * i] = 1;
    for (r2 = 0; r2 < 6; r2++) {
      L[i + 3 * r2] = 0.0;
      for (r3 = 0; r3 < 6; r3++) {
        maxval = L[3 * r2 + i];
        maxval += Cm[3 * r3 + i] * TV_ol_B.LastPcov[6 * r2 + r3];
        L[i + 3 * r2] = maxval;
      }
    }

    for (r2 = 0; r2 < 3; r2++) {
      b_A_4 = 0.0;
      for (r3 = 0; r3 < 6; r3++) {
        b_A_4 += L[3 * r3 + i] * Cm[3 * r3 + r2];
      }

      c_A[i + 3 * r2] = CovMat[((r2 + 6) * 9 + i) + 6] + b_A_4;
    }
  }

  i = 0;
  r2 = 1;
  r3 = 2;
  maxval = fabs(c_A[0]);
  a21 = fabs(c_A[1]);
  if (a21 > maxval) {
    maxval = a21;
    i = 1;
    r2 = 0;
  }

  if (fabs(c_A[2]) > maxval) {
    i = 2;
    r2 = 1;
    r3 = 0;
  }

  c_A[r2] /= c_A[i];
  c_A[r3] /= c_A[i];
  c_A[r2 + 3] -= c_A[i + 3] * c_A[r2];
  c_A[r3 + 3] -= c_A[i + 3] * c_A[r3];
  c_A[r2 + 6] -= c_A[i + 6] * c_A[r2];
  c_A[r3 + 6] -= c_A[i + 6] * c_A[r3];
  if (fabs(c_A[r3 + 3]) > fabs(c_A[r2 + 3])) {
    int32_T rtemp;
    rtemp = r2;
    r2 = r3;
    r3 = rtemp;
  }

  c_A[r3 + 3] /= c_A[r2 + 3];
  c_A[r3 + 6] -= c_A[r3 + 3] * c_A[r2 + 6];
  Kinv[3 * i] = (real_T)c_B[0] / c_A[i];
  Kinv[3 * r2] = (real_T)c_B[3] - Kinv[3 * i] * c_A[i + 3];
  Kinv[3 * r3] = (real_T)c_B[6] - Kinv[3 * i] * c_A[i + 6];
  Kinv[3 * r2] /= c_A[r2 + 3];
  Kinv[3 * r3] -= Kinv[3 * r2] * c_A[r2 + 6];
  Kinv[3 * r3] /= c_A[r3 + 6];
  Kinv[3 * r2] -= Kinv[3 * r3] * c_A[r3 + 3];
  Kinv[3 * i] -= Kinv[3 * r3] * c_A[r3];
  Kinv[3 * i] -= Kinv[3 * r2] * c_A[r2];
  Kinv[3 * i + 1] = (real_T)c_B[1] / c_A[i];
  Kinv[3 * r2 + 1] = (real_T)c_B[4] - Kinv[3 * i + 1] * c_A[i + 3];
  Kinv[3 * r3 + 1] = (real_T)c_B[7] - Kinv[3 * i + 1] * c_A[i + 6];
  Kinv[3 * r2 + 1] /= c_A[r2 + 3];
  Kinv[3 * r3 + 1] -= Kinv[3 * r2 + 1] * c_A[r2 + 6];
  Kinv[3 * r3 + 1] /= c_A[r3 + 6];
  Kinv[3 * r2 + 1] -= Kinv[3 * r3 + 1] * c_A[r3 + 3];
  Kinv[3 * i + 1] -= Kinv[3 * r3 + 1] * c_A[r3];
  Kinv[3 * i + 1] -= Kinv[3 * r2 + 1] * c_A[r2];
  Kinv[3 * i + 2] = (real_T)c_B[2] / c_A[i];
  Kinv[3 * r2 + 2] = (real_T)c_B[5] - Kinv[3 * i + 2] * c_A[i + 3];
  Kinv[3 * r3 + 2] = (real_T)c_B[8] - Kinv[3 * i + 2] * c_A[i + 6];
  Kinv[3 * r2 + 2] /= c_A[r2 + 3];
  Kinv[3 * r3 + 2] -= Kinv[3 * r2 + 2] * c_A[r2 + 6];
  Kinv[3 * r3 + 2] /= c_A[r3 + 6];
  Kinv[3 * r2 + 2] -= Kinv[3 * r3 + 2] * c_A[r3 + 3];
  Kinv[3 * i + 2] -= Kinv[3 * r3 + 2] * c_A[r3];
  Kinv[3 * i + 2] -= Kinv[3 * r2 + 2] * c_A[r2];

  /* :  L = (A(:,:,1)*Pk*Cm(:,:,1)' + Nk)*Kinv; */
  /* :  M = Pk*Cm(:,:,1)'*Kinv; */
  /* :  ym = ym.*RYscale(myindex) - myoff; */
  /* :  xk = xk + Bu(:,:,1)*delmv; */
  for (r2 = 0; r2 < 6; r2++) {
    for (r3 = 0; r3 < 6; r3++) {
      b_A_0[r2 + 6 * r3] = 0.0;
      for (i = 0; i < 6; i++) {
        b_A_4 = b_A_0[6 * r3 + r2];
        b_A_4 += b_A[6 * i + r2] * TV_ol_B.LastPcov[6 * r3 + i];
        b_A_0[r2 + 6 * r3] = b_A_4;
      }
    }

    for (r3 = 0; r3 < 3; r3++) {
      b_A_4 = 0.0;
      for (i = 0; i < 6; i++) {
        b_A_4 += b_A_0[6 * i + r2] * Cm[3 * i + r3];
      }

      b_A_1[r2 + 6 * r3] = CovMat[(r3 + 6) * 9 + r2] + b_A_4;
    }

    for (r3 = 0; r3 < 3; r3++) {
      L[r2 + 6 * r3] = 0.0;
      L_0 = L[6 * r3 + r2];
      L_0 += Kinv[3 * r3] * b_A_1[r2];
      L[r2 + 6 * r3] = L_0;
      L_0 = L[6 * r3 + r2];
      L_0 += Kinv[3 * r3 + 1] * b_A_1[r2 + 6];
      L[r2 + 6 * r3] = L_0;
      L_0 = L[6 * r3 + r2];
      L_0 += Kinv[3 * r3 + 2] * b_A_1[r2 + 12];
      L[r2 + 6 * r3] = L_0;
    }

    xk[r2] = TV_ol_B.last_x[r2] - b_xoff[r2];
  }

  /* :  ym_est = Cm(:,:,1)*xk + Dvm(:,:,1)*v; */
  /* :  y_innov = ym - ym_est; */
  for (r2 = 0; r2 < 3; r2++) {
    b_A_4 = 0.0;
    for (r3 = 0; r3 < 6; r3++) {
      b_A_4 += Cm[3 * r3 + r2] * xk[r3];
    }

    y_innov[r2] = (TV_ol_B.VectorConcatenate[r2] - Y[r2]) - b_A_4;
  }

  /* :  xest = xk + M*y_innov; */
  for (r2 = 0; r2 < 6; r2++) {
    for (r3 = 0; r3 < 3; r3++) {
      b_A_1[r2 + 6 * r3] = 0.0;
      for (i = 0; i < 6; i++) {
        b_A_4 = b_A_1[6 * r3 + r2];
        b_A_4 += TV_ol_B.LastPcov[6 * i + r2] * Cm[3 * i + r3];
        b_A_1[r2 + 6 * r3] = b_A_4;
      }
    }

    b_A_4 = 0.0;
    for (r3 = 0; r3 < 3; r3++) {
      tmp[r2 + 6 * r3] = 0.0;
      maxval = tmp[6 * r3 + r2];
      maxval += Kinv[3 * r3] * b_A_1[r2];
      tmp[r2 + 6 * r3] = maxval;
      maxval = tmp[6 * r3 + r2];
      maxval += Kinv[3 * r3 + 1] * b_A_1[r2 + 6];
      tmp[r2 + 6 * r3] = maxval;
      maxval = tmp[6 * r3 + r2];
      maxval += Kinv[3 * r3 + 2] * b_A_1[r2 + 12];
      tmp[r2 + 6 * r3] = maxval;
      b_A_4 += tmp[6 * r3 + r2] * y_innov[r3];
    }

    TV_ol_B.xest[r2] = xk[r2] + b_A_4;
  }

  /* :  if no_uref */
  /* :  utargetValue = utarget; */
  /* :  if ~no_cc */
  /* :  return_sequence = return_mvseq || return_xseq || return_ovseq; */
  /* :  if isSimulation */
  /* :  else */
  /* :  [u, cost, useq, status, iAout] = mpcblock_optimizer(... */
  /* :              rseq, vseq, umin, umax, ymin, ymax, switch_in, xest, old_u, iA, ... */
  /* :              isQP, nu, ny, degrees, Hinv, Kx, Ku1, Kut, Kr, Kv, Mlim, ... */
  /* :              Mx, Mu1, Mv, utargetValue, p, uoff, voff, yoff, ... */
  /* :              false, CustomSolverCodeGen, UseSuboptimalSolution, ... */
  /* :              UseActiveSetSolver, ASOptions, IPOptions, MIQPOptions, nxQP, openloopflag, ... */
  /* :              no_umin, no_umax, no_ymin, no_ymax, no_cc, switch_inport, ... */
  /* :              no_switch, enable_value, return_cost, H, return_sequence, Linv, Ac, ... */
  /* :              ywt, uwt, duwt, ewt, no_ywt, no_uwt, no_duwt, no_rhoeps,... */
  /* :              Wy, Wdu, Jm, SuJm, Su1, Sx, Hv, Wu, I1, ... */
  /* :              isAdaptive, isLTV, A, Bu, Bv, C, Dv, ... */
  /* :              Mrows, nCC, Ecc, Fcc, Scc, Gcc, RYscale, RMVscale, m, isHyb, Mdis, Ndis, Vdis, numdis, maxdis); */
  TV_ol_mpcblock_optimizer(rseq, vseq, TV_ol_B.xest, TV_ol_B.last_mv,
    TV_ol_B.Memory, b_utarget, 0.0, b_A, Bu, Bv, b_C, Dv, &a21, TV_ol_B.useq,
    &maxval, &iAout);
  TV_ol_B.cost = 0.0;
  TV_ol_B.u = a21;

  /* :  if return_xseq || return_ovseq */
  /* :  else */
  /* :  yseq = zeros(p+1,ny,'like',rseq); */
  memset(&TV_ol_B.yseq[0], 0, 33U * sizeof(real_T));

  /* :  xseq = zeros(p+1,nxQP,'like',rseq); */
  memset(&TV_ol_B.xseq[0], 0, 66U * sizeof(real_T));

  /* :  if CustomEstimation */
  /* :  else */
  /* :  xk1 = A(:,:,1)*xk + Bu(:,:,1)*(u - uoff) + Bv(:,:,1)*v + L*y_innov; */
  /* :  Pk1 = A(:,:,1)*Pk*A(:,:,1)' - (A(:,:,1)*Pk*Cm(:,:,1)' + Nk)*L' + Qk; */
  for (r2 = 0; r2 < 6; r2++) {
    for (r3 = 0; r3 < 6; r3++) {
      b_A_0[r2 + 6 * r3] = 0.0;
      b_A_2[r2 + 6 * r3] = 0.0;
      for (i = 0; i < 6; i++) {
        b_A_4 = b_A_2[6 * r3 + r2];
        b_A_5 = b_A[6 * i + r2];
        L_0 = b_A_0[6 * r3 + r2];
        L_0 += TV_ol_B.LastPcov[6 * r3 + i] * b_A_5;
        b_A_4 += TV_ol_B.LastPcov[6 * r3 + i] * b_A_5;
        b_A_0[r2 + 6 * r3] = L_0;
        b_A_2[r2 + 6 * r3] = b_A_4;
      }
    }

    for (r3 = 0; r3 < 3; r3++) {
      b_A_4 = 0.0;
      for (i = 0; i < 6; i++) {
        b_A_4 += b_A_2[6 * i + r2] * Cm[3 * i + r3];
      }

      b_A_1[r2 + 6 * r3] = CovMat[(r3 + 6) * 9 + r2] + b_A_4;
    }

    for (r3 = 0; r3 < 6; r3++) {
      b_A_3[r2 + 6 * r3] = 0.0;
      for (i = 0; i < 6; i++) {
        b_A_4 = b_A_3[6 * r3 + r2];
        b_A_4 += b_A_0[6 * i + r2] * b_A[6 * i + r3];
        b_A_3[r2 + 6 * r3] = b_A_4;
      }
    }
  }

  for (r2 = 0; r2 < 6; r2++) {
    for (r3 = 0; r3 < 6; r3++) {
      b_A_0[r2 + 6 * r3] = 0.0;
      b_A_4 = b_A_0[6 * r3 + r2];
      b_A_4 += b_A_1[r2] * L[r3];
      b_A_0[r2 + 6 * r3] = b_A_4;
      b_A_4 = b_A_0[6 * r3 + r2];
      b_A_4 += b_A_1[r2 + 6] * L[r3 + 6];
      b_A_0[r2 + 6 * r3] = b_A_4;
      b_A_4 = b_A_0[6 * r3 + r2];
      b_A_4 += b_A_1[r2 + 12] * L[r3 + 12];
      b_A_0[r2 + 6 * r3] = b_A_4;
    }
  }

  for (r2 = 0; r2 < 6; r2++) {
    for (r3 = 0; r3 <= 4; r3 += 2) {
      __m128d tmp_0;
      __m128d tmp_1;
      tmp_0 = _mm_loadu_pd(&b_A_3[6 * r2 + r3]);
      tmp_1 = _mm_loadu_pd(&b_A_0[6 * r2 + r3]);
      tmp_0 = _mm_sub_pd(tmp_0, tmp_1);
      tmp_1 = _mm_loadu_pd(&CovMat[9 * r2 + r3]);
      tmp_0 = _mm_add_pd(tmp_0, tmp_1);
      _mm_storeu_pd(&b_A_2[r3 + 6 * r2], tmp_0);
    }
  }

  /* :  Pk1 = 0.5*(Pk1 + Pk1'); */
  /* :  xk1 = xk1 + xoff; */
  /* :  xest = xest + xoff; */
  for (r2 = 0; r2 < 6; r2++) {
    b_A_5 = b_xoff[r2];
    b_A_4 = 0.0;
    for (r3 = 0; r3 < 6; r3++) {
      TV_ol_B.Pk1[r3 + 6 * r2] = (b_A_2[6 * r2 + r3] + b_A_2[6 * r3 + r2]) * 0.5;
      b_A_4 += b_A[6 * r3 + r2] * xk[r3];
    }

    b_A_4 = (Bu[r2] * a21 + b_A_4) + Bv[r2];
    L_0 = L[r2] * y_innov[0];
    L_0 += L[r2 + 6] * y_innov[1];
    L_0 += L[r2 + 12] * y_innov[2];
    TV_ol_B.xk1[r2] = (b_A_4 + L_0) + b_A_5;
    TV_ol_B.xest[r2] += b_A_5;
  }

  TV_ol_B.status = maxval;
  TV_ol_B.iAout = iAout;

  /* End of MATLAB Function: '<S41>/FixedHorizonOptimizer' */

  /* Gain: '<S13>/u_scale' */
  TV_ol_B.u_scale = TV_ol_P.u_scale_Gain * TV_ol_B.u;

  /* Bias: '<S10>/NominalU1' */
  TV_ol_B.NominalU1 = TV_ol_B.u_scale + TV_ol_P.NominalU1_Bias;

  /* Saturate: '<S8>/Yaw moment saturation' */
  maxval = TV_ol_B.NominalU1;
  a21 = TV_ol_P.LowerYawMoment;
  b_A_4 = TV_ol_P.UpperYawMoment;
  if (maxval > b_A_4) {
    /* Saturate: '<S8>/Yaw moment saturation' */
    TV_ol_B.Yawmomentsaturation = b_A_4;
  } else if (maxval < a21) {
    /* Saturate: '<S8>/Yaw moment saturation' */
    TV_ol_B.Yawmomentsaturation = a21;
  } else {
    /* Saturate: '<S8>/Yaw moment saturation' */
    TV_ol_B.Yawmomentsaturation = maxval;
  }

  /* End of Saturate: '<S8>/Yaw moment saturation' */

  /* Product: '<S8>/Product2' */
  TV_ol_B.Product2 = (real_T)TV_ol_B.AND * TV_ol_B.Yawmomentsaturation;

  /* Saturate: '<S5>/Yaw moment saturation' */
  maxval = TV_ol_B.Product2;
  a21 = TV_ol_P.LowerYawMoment;
  b_A_4 = TV_ol_P.UpperYawMoment;
  if (maxval > b_A_4) {
    /* Saturate: '<S5>/Yaw moment saturation' */
    TV_ol_B.Yawmomentsaturation_a = b_A_4;
  } else if (maxval < a21) {
    /* Saturate: '<S5>/Yaw moment saturation' */
    TV_ol_B.Yawmomentsaturation_a = a21;
  } else {
    /* Saturate: '<S5>/Yaw moment saturation' */
    TV_ol_B.Yawmomentsaturation_a = maxval;
  }

  /* End of Saturate: '<S5>/Yaw moment saturation' */

  /* Gain: '<S7>/Gain3' */
  TV_ol_B.Gain3 = TV_ol_P.Gain3_Gain * TV_ol_B.Yawmomentsaturation_a;

  /* Gain: '<S7>/Gain1' */
  TV_ol_B.Gain1 = TV_ol_P.Rd * TV_ol_B.Gain3;

  /* Product: '<S7>/Divide1' incorporates:
   *  Constant: '<S7>/Constant'
   */
  a21 = 2.0 * TV_ol_P.wr * TV_ol_P.Gr;

  /* Product: '<S7>/Divide1' */
  TV_ol_B.Desiredtorquedifferenceatfronta = TV_ol_B.Gain1 / a21;

  /* Outport: '<Root>/TVFL' incorporates:
   *  Gain: '<S4>/Gain'
   */
  TV_ol_Y.TVFL = TV_ol_P.Gain_Gain * TV_ol_B.Desiredtorquedifferenceatfronta;

  /* Outport: '<Root>/TVFR' incorporates:
   *  Outport: '<Root>/TVFL'
   */
  TV_ol_Y.TVFR = TV_ol_Y.TVFL;

  /* Gain: '<S7>/Gain2' */
  TV_ol_B.Gain2_m = TV_ol_P.Gain2_Gain_o * TV_ol_B.Yawmomentsaturation_a;

  /* Gain: '<S7>/Gain' */
  TV_ol_B.Gain_g = TV_ol_P.Rd * TV_ol_B.Gain2_m;

  /* Product: '<S7>/Divide2' incorporates:
   *  Constant: '<S7>/Constant1'
   */
  a21 = 2.0 * TV_ol_P.wf * TV_ol_P.Gr;

  /* Product: '<S7>/Divide2' */
  TV_ol_B.Desiredtorquedifferenceatrearax = TV_ol_B.Gain_g / a21;

  /* Outport: '<Root>/TVRL' incorporates:
   *  Gain: '<S4>/Gain1'
   */
  TV_ol_Y.TVRL = TV_ol_P.Gain1_Gain * TV_ol_B.Desiredtorquedifferenceatrearax;

  /* Outport: '<Root>/TVRR' incorporates:
   *  Outport: '<Root>/TVRL'
   */
  TV_ol_Y.TVRR = TV_ol_Y.TVRL;

  /* Update for Memory: '<S13>/last_x' */
  for (i = 0; i < 6; i++) {
    TV_ol_DW.last_x_PreviousInput[i] = TV_ol_B.xk1[i];
  }

  /* End of Update for Memory: '<S13>/last_x' */

  /* Update for UnitDelay: '<S13>/last_mv' */
  TV_ol_DW.last_mv_DSTATE = TV_ol_B.u;

  /* Update for Memory: '<S13>/LastPcov' */
  memcpy(&TV_ol_DW.LastPcov_PreviousInput[0], &TV_ol_B.Pk1[0], 36U * sizeof
         (real_T));

  /* Update for Memory: '<S13>/Memory' */
  TV_ol_DW.Memory_PreviousInput = TV_ol_B.iAout;

  /* Matfile logging */
  rt_UpdateTXYLogVars(TV_ol_M->rtwLogInfo, (&TV_ol_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.001s, 0.0s] */
    if ((rtmGetTFinal(TV_ol_M)!=-1) &&
        !((rtmGetTFinal(TV_ol_M)-TV_ol_M->Timing.taskTime0) >
          TV_ol_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(TV_ol_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++TV_ol_M->Timing.clockTick0)) {
    ++TV_ol_M->Timing.clockTickH0;
  }

  TV_ol_M->Timing.taskTime0 = TV_ol_M->Timing.clockTick0 *
    TV_ol_M->Timing.stepSize0 + TV_ol_M->Timing.clockTickH0 *
    TV_ol_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void TV_ol_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)TV_ol_M, 0,
                sizeof(RT_MODEL_TV_ol_T));
  rtmSetTFinal(TV_ol_M, 10.0);
  TV_ol_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    TV_ol_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(TV_ol_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(TV_ol_M->rtwLogInfo, (NULL));
    rtliSetLogT(TV_ol_M->rtwLogInfo, "tout");
    rtliSetLogX(TV_ol_M->rtwLogInfo, "");
    rtliSetLogXFinal(TV_ol_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(TV_ol_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(TV_ol_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(TV_ol_M->rtwLogInfo, 0);
    rtliSetLogDecimation(TV_ol_M->rtwLogInfo, 1);
    rtliSetLogY(TV_ol_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(TV_ol_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(TV_ol_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &TV_ol_B), 0,
                sizeof(B_TV_ol_T));

  /* states (dwork) */
  (void) memset((void *)&TV_ol_DW, 0,
                sizeof(DW_TV_ol_T));

  /* external inputs */
  (void)memset(&TV_ol_U, 0, sizeof(ExtU_TV_ol_T));

  /* external outputs */
  (void)memset(&TV_ol_Y, 0, sizeof(ExtY_TV_ol_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(TV_ol_M->rtwLogInfo, 0.0, rtmGetTFinal
    (TV_ol_M), TV_ol_M->Timing.stepSize0, (&rtmGetErrorStatus(TV_ol_M)));

  {
    int32_T i;

    /* InitializeConditions for Memory: '<S13>/last_x' */
    for (i = 0; i < 6; i++) {
      TV_ol_DW.last_x_PreviousInput[i] = TV_ol_P.last_x_InitialCondition[i];
    }

    /* End of InitializeConditions for Memory: '<S13>/last_x' */

    /* InitializeConditions for UnitDelay: '<S13>/last_mv' */
    TV_ol_DW.last_mv_DSTATE = TV_ol_P.last_mv_InitialCondition;

    /* InitializeConditions for Memory: '<S13>/LastPcov' */
    memcpy(&TV_ol_DW.LastPcov_PreviousInput[0],
           &TV_ol_P.LastPcov_InitialCondition[0], 36U * sizeof(real_T));

    /* InitializeConditions for Memory: '<S13>/Memory' */
    TV_ol_DW.Memory_PreviousInput = TV_ol_P.Memory_InitialCondition;
  }
}

/* Model terminate function */
void TV_ol_terminate(void)
{
  /* (no terminate code required) */
}
