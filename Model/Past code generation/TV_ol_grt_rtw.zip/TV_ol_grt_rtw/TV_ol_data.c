/*
 * TV_ol_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TV_ol".
 *
 * Model version              : 3.15
 * Simulink Coder version : 9.8 (R2022b) 13-May-2022
 * C source code generated on : Sat Jan 13 17:12:32 2024
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "TV_ol.h"

/* Block parameters (default storage) */
P_TV_ol_T TV_ol_P = {
  /* Variable: Gr
   * Referenced by:
   *   '<S7>/Constant'
   *   '<S7>/Constant1'
   */
  12.0,

  /* Variable: Ku
   * Referenced by: '<S6>/Gain'
   */
  0.0,

  /* Variable: LowerYawMoment
   * Referenced by:
   *   '<S5>/Yaw moment saturation'
   *   '<S8>/Yaw moment saturation'
   */
  -3600.0,

  /* Variable: Rd
   * Referenced by:
   *   '<S7>/Gain'
   *   '<S7>/Gain1'
   */
  0.205,

  /* Variable: Sgr
   * Referenced by: '<S6>/Gain1'
   */
  5.0,

  /* Variable: SteeringDeadzonelimit
   * Referenced by: '<S3>/Dead Zone'
   */
  10.0,

  /* Variable: UpperYawMoment
   * Referenced by:
   *   '<S5>/Yaw moment saturation'
   *   '<S8>/Yaw moment saturation'
   */
  3600.0,

  /* Variable: g
   * Referenced by: '<S6>/Constant2'
   */
  9.81,

  /* Variable: l
   * Referenced by: '<S6>/Constant'
   */
  1.53,

  /* Variable: myy
   * Referenced by: '<S6>/Constant1'
   */
  2.0,

  /* Variable: wf
   * Referenced by: '<S7>/Constant1'
   */
  0.6,

  /* Variable: wr
   * Referenced by: '<S7>/Constant'
   */
  0.6,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S2>/Constant'
   */
  2.4,

  /* Expression: lastx+xoff
   * Referenced by: '<S13>/last_x'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: lastu+uoff
   * Referenced by: '<S13>/last_mv'
   */
  0.0,

  /* Expression: 180/pi
   * Referenced by: '<S6>/Gain2'
   */
  57.295779513082323,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/md_zero'
   */
  0.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/umin_zero'
   */
  0.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/umax_zero'
   */
  0.0,

  /* Expression: zeros(3,1)
   * Referenced by: '<S11>/ymin_zero'
   */
  { 0.0, 0.0, 0.0 },

  /* Expression: zeros(3,1)
   * Referenced by: '<S11>/ymax_zero'
   */
  { 0.0, 0.0, 0.0 },

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/E_zero'
   */
  0.0,

  /* Expression: MVscale(:,ones(1,max(nCC,1)))'
   * Referenced by: '<S13>/umin_scale4'
   */
  1.0,

  /* Expression: zeros(1,3)
   * Referenced by: '<S11>/F_zero'
   */
  { 0.0, 0.0, 0.0 },

  /* Expression: Yscale(:,ones(1,max(nCC,1)))'
   * Referenced by: '<S13>/ymin_scale1'
   */
  { 1.0, 1.0, 1.0 },

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/G_zero'
   */
  0.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/S_zero'
   */
  0.0,

  /* Expression: MDscale(:,ones(1,max(nCC,1)))'
   * Referenced by: '<S13>/ymin_scale2'
   */
  1.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/switch_zero'
   */
  0.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/ext.mv_zero'
   */
  0.0,

  /* Expression: RMVscale
   * Referenced by: '<S13>/ext.mv_scale'
   */
  1.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/mv.target_zero'
   */
  0.0,

  /* Expression: RMVscale
   * Referenced by: '<S13>/uref_scale'
   */
  1.0,

  /* Expression: zeros(3,1)
   * Referenced by: '<S11>/y.wt_zero'
   */
  { 0.0, 0.0, 0.0 },

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/u.wt_zero'
   */
  0.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/du.wt_zero'
   */
  0.0,

  /* Expression: zeros(1,1)
   * Referenced by: '<S11>/ecr.wt_zero'
   */
  0.0,

  /* Expression: lastPcov
   * Referenced by: '<S13>/LastPcov'
   */
  { 40.356067777577223, -8.69429828976687E-15, 0.0, 0.0054305592281633768,
    2.5509322431619287E-8, -5.4006636174725254E-16, -8.69429828976687E-15,
    5.1020408163275479E-5, 0.0, -6.0305977212050709E-19, -6.2598254004160922E-19,
    -1.8629983952363266E-18, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0054305592281633768,
    -6.0305977212050709E-19, 0.0, 0.0010012313566500248, -3.4310502326087544E-9,
    -9.414315546632912E-17, 2.5509322431619287E-8, -6.2598254004160922E-19, 0.0,
    -3.4310502326087544E-9, 0.0010005256348691377, -2.99533062924162E-16,
    -5.4006636174725254E-16, -1.8629983952363266E-18, 0.0,
    -9.414315546632912E-17, -2.99533062924162E-16, 0.0010005001249999129 },

  /* Expression: MVscale
   * Referenced by: '<S13>/u_scale'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S10>/NominalU1'
   */
  0.0,

  /* Expression: 0.5
   * Referenced by: '<S7>/Gain3'
   */
  0.5,

  /* Expression: 0.5
   * Referenced by: '<S4>/Gain'
   */
  0.5,

  /* Expression: 0.5
   * Referenced by: '<S7>/Gain2'
   */
  0.5,

  /* Expression: 0.5
   * Referenced by: '<S4>/Gain1'
   */
  0.5,

  /* Expression: Ndis
   * Referenced by: '<S41>/FixedHorizonOptimizer'
   */
  0,

  /* Expression: iA
   * Referenced by: '<S13>/Memory'
   */
  false
};
