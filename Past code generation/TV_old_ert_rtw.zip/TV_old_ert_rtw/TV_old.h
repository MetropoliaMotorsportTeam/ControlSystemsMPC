/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 *
 * File: TV_old.h
 *
 * Code generated for Simulink model 'TV_old'.
 *
 * Model version                  : 1.30
 * Simulink Coder version         : 9.6 (R2021b) 14-May-2021
 * C/C++ source code generated on : Sat Jan 13 18:58:54 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_TV_old_h_
#define RTW_HEADER_TV_old_h_
#include "rtwtypes.h"
#include <stddef.h>
#include <emmintrin.h>
#include <math.h>
#include <string.h>
#ifndef TV_old_COMMON_INCLUDES_
#define TV_old_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* TV_old_COMMON_INCLUDES_ */

/* Model Code Variants */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

#ifndef DEFINED_TYPEDEF_FOR_struct_WTmPWsEMvOzNnnAVv5fQNC_
#define DEFINED_TYPEDEF_FOR_struct_WTmPWsEMvOzNnnAVv5fQNC_

typedef struct {
  int32_T MaxIterations;
  real_T ConstraintTolerance;
  boolean_T UseWarmStart;
} struct_WTmPWsEMvOzNnnAVv5fQNC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_WHjMt45Sk148iktWsfFxl_
#define DEFINED_TYPEDEF_FOR_struct_WHjMt45Sk148iktWsfFxl_

typedef struct {
  int32_T MaxIterations;
  real_T ConstraintTolerance;
  real_T OptimalityTolerance;
  real_T ComplementarityTolerance;
  real_T StepTolerance;
} struct_WHjMt45Sk148iktWsfFxl;

#endif

#ifndef DEFINED_TYPEDEF_FOR_struct_lnQ9KXdSZFplhcBp5LBCc_
#define DEFINED_TYPEDEF_FOR_struct_lnQ9KXdSZFplhcBp5LBCc_

typedef struct {
  int32_T MaxIterations;
  real_T ConstraintTolerance;
  real_T DiscreteConstraintTolerance;
  boolean_T RoundingAtRootNode;
  int32_T MaxPendingNodes;
} struct_lnQ9KXdSZFplhcBp5LBCc;

#endif

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  real_T last_x_PreviousInput[6];      /* '<S14>/last_x' */
  real_T LastPcov_PreviousInput[36];   /* '<S14>/LastPcov' */
  real_T last_mv_DSTATE;               /* '<S14>/last_mv' */
  boolean_T Memory_PreviousInput;      /* '<S14>/Memory' */
} DW;

/* Constant parameters (default storage) */
typedef struct {
  /* Expression: lastPcov
   * Referenced by: '<S14>/LastPcov'
   */
  real_T LastPcov_InitialCondition[36];
} ConstP;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T StrAngleDeg;                  /* '<Root>/StrAngleDeg' */
  real_T VehicleSpeed;                 /* '<Root>/VehicleSpeed' */
  real_T TorqueVectoringEnabled;       /* '<Root>/TorqueVectoringEnabled' */
  real_T VehicleYawRate;               /* '<Root>/VehicleYawRate' */
  boolean_T FeedbackEnabled;           /* '<Root>/FeedbackEnabled' */
  boolean_T FeedForwardEnabled;        /* '<Root>/FeedForwardEnabled' */
  real_T LateralVelocity;              /* '<Root>/LateralVelocity' */
} ExtU;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T TVFL;                         /* '<Root>/TVFL' */
  real_T TVFR;                         /* '<Root>/TVFR' */
  real_T TVRL;                         /* '<Root>/TVRL' */
  real_T TVRR;                         /* '<Root>/TVRR' */
} ExtY;

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T * volatile errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint8_T TID[2];
    } TaskCounters;
  } Timing;
};

/* Block signals and states (default storage) */
extern DW rtDW;

/* External inputs (root inport signals with default storage) */
extern ExtU rtU;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY rtY;

/* Constant parameters (default storage) */
extern const ConstP rtConstP;

/* Model entry point functions */
extern void TV_old_initialize(void);
extern void TV_old_step(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S14>/Floor' : Unused code path elimination
 * Block '<S14>/Floor1' : Unused code path elimination
 * Block '<S15>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S16>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S17>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S18>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S19>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S20>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S21>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S22>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S23>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S24>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S25>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S26>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S27>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S28>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S29>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S30>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S31>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S32>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S33>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S34>/Matrix Dimension Check' : Unused code path elimination
 * Block '<S35>/Vector Dimension Check' : Unused code path elimination
 * Block '<S36>/Vector Dimension Check' : Unused code path elimination
 * Block '<S37>/Vector Dimension Check' : Unused code path elimination
 * Block '<S38>/Vector Dimension Check' : Unused code path elimination
 * Block '<S39>/Vector Dimension Check' : Unused code path elimination
 * Block '<S40>/Vector Dimension Check' : Unused code path elimination
 * Block '<S41>/Vector Dimension Check' : Unused code path elimination
 * Block '<S14>/useq_scale' : Unused code path elimination
 * Block '<S14>/useq_scale1' : Unused code path elimination
 * Block '<S14>/ym_zero' : Unused code path elimination
 * Block '<S11>/m_zero' : Unused code path elimination
 * Block '<S11>/p_zero' : Unused code path elimination
 * Block '<S10>/Dead Zone' : Unused code path elimination
 * Block '<S68>/AND3' : Unused code path elimination
 * Block '<S68>/Constant1' : Unused code path elimination
 * Block '<S68>/DataTypeConv1' : Unused code path elimination
 * Block '<S68>/DataTypeConv2' : Unused code path elimination
 * Block '<S70>/DeadZone' : Unused code path elimination
 * Block '<S68>/Equal1' : Unused code path elimination
 * Block '<S68>/NotEqual' : Unused code path elimination
 * Block '<S68>/SignPreIntegrator' : Unused code path elimination
 * Block '<S68>/SignPreSat' : Unused code path elimination
 * Block '<S68>/Switch' : Unused code path elimination
 * Block '<S68>/ZeroGain' : Unused code path elimination
 * Block '<S74>/IProd Out' : Unused code path elimination
 * Block '<S77>/Integrator' : Unused code path elimination
 * Block '<S82>/PProd Out' : Unused code path elimination
 * Block '<S84>/Saturation' : Unused code path elimination
 * Block '<S86>/Sum' : Unused code path elimination
 * Block '<S10>/Gain' : Unused code path elimination
 * Block '<S10>/Gain1' : Unused code path elimination
 * Block '<S10>/Gain2' : Unused code path elimination
 * Block '<S10>/I gains' : Unused code path elimination
 * Block '<S10>/P gains' : Unused code path elimination
 * Block '<S10>/Scope' : Unused code path elimination
 * Block '<S10>/Scope1' : Unused code path elimination
 * Block '<S10>/Sum1' : Unused code path elimination
 * Block '<S9>/AND' : Unused code path elimination
 * Block '<S9>/Constant' : Unused code path elimination
 * Block '<S9>/Product' : Unused code path elimination
 * Block '<S9>/Product2' : Unused code path elimination
 * Block '<S9>/Yaw moment saturation' : Unused code path elimination
 * Block '<S14>/Reshape' : Reshape block reduction
 * Block '<S14>/Reshape1' : Reshape block reduction
 * Block '<S14>/Reshape2' : Reshape block reduction
 * Block '<S14>/Reshape3' : Reshape block reduction
 * Block '<S14>/Reshape4' : Reshape block reduction
 * Block '<S14>/Reshape5' : Reshape block reduction
 * Block '<S14>/ext.mv_scale' : Eliminated nontunable gain of 1
 * Block '<S14>/u_scale' : Eliminated nontunable gain of 1
 * Block '<S14>/umin_scale4' : Eliminated nontunable gain of 1
 * Block '<S14>/uref_scale' : Eliminated nontunable gain of 1
 * Block '<S14>/ymin_scale1' : Eliminated nontunable gain of 1
 * Block '<S14>/ymin_scale2' : Eliminated nontunable gain of 1
 * Block '<S10>/NominalU1' : Eliminated nontunable bias of 0
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'TV_old'
 * '<S1>'   : 'TV_old/Subsystem'
 * '<S2>'   : 'TV_old/Subsystem/Compare To Constant'
 * '<S3>'   : 'TV_old/Subsystem/If steering angle is between -10 and 10 degrees system is off '
 * '<S4>'   : 'TV_old/Subsystem/Yaw moment distribution'
 * '<S5>'   : 'TV_old/Subsystem/Yaw rate controller'
 * '<S6>'   : 'TV_old/Subsystem/Yaw rate reference calculation'
 * '<S7>'   : 'TV_old/Subsystem/Yaw moment distribution/Lateral torque distribution'
 * '<S8>'   : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type'
 * '<S9>'   : 'TV_old/Subsystem/Yaw rate controller/Feedforward controller type'
 * '<S10>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type'
 * '<S11>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller'
 * '<S12>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller'
 * '<S13>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/MATLAB Function'
 * '<S14>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC'
 * '<S15>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check'
 * '<S16>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check A'
 * '<S17>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check B'
 * '<S18>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check C'
 * '<S19>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check D'
 * '<S20>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check DX'
 * '<S21>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check U'
 * '<S22>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check X'
 * '<S23>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check Y'
 * '<S24>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check1'
 * '<S25>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Matrix Signal Check2'
 * '<S26>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check'
 * '<S27>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check1'
 * '<S28>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check2'
 * '<S29>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check3'
 * '<S30>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check4'
 * '<S31>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check5'
 * '<S32>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check6'
 * '<S33>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check7'
 * '<S34>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Preview Signal Check8'
 * '<S35>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Scalar Signal Check'
 * '<S36>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Scalar Signal Check1'
 * '<S37>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Scalar Signal Check2'
 * '<S38>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Vector Signal Check'
 * '<S39>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Vector Signal Check1'
 * '<S40>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/MPC Vector Signal Check6'
 * '<S41>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/moorx'
 * '<S42>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/optimizer'
 * '<S43>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Adaptive MPC Controller/MPC/optimizer/FixedHorizonOptimizer'
 * '<S44>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Anti-windup'
 * '<S45>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/D Gain'
 * '<S46>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Filter'
 * '<S47>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Filter ICs'
 * '<S48>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/I Gain'
 * '<S49>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Ideal P Gain'
 * '<S50>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Ideal P Gain Fdbk'
 * '<S51>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Integrator'
 * '<S52>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Integrator ICs'
 * '<S53>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/N Copy'
 * '<S54>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/N Gain'
 * '<S55>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/P Copy'
 * '<S56>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Parallel P Gain'
 * '<S57>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Reset Signal'
 * '<S58>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Saturation'
 * '<S59>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Saturation Fdbk'
 * '<S60>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Sum'
 * '<S61>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Sum Fdbk'
 * '<S62>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tracking Mode'
 * '<S63>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tracking Mode Sum'
 * '<S64>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tsamp - Integral'
 * '<S65>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tsamp - Ngain'
 * '<S66>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/postSat Signal'
 * '<S67>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/preSat Signal'
 * '<S68>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel'
 * '<S69>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
 * '<S70>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
 * '<S71>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/D Gain/Disabled'
 * '<S72>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Filter/Disabled'
 * '<S73>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Filter ICs/Disabled'
 * '<S74>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/I Gain/External Parameters'
 * '<S75>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Ideal P Gain/Passthrough'
 * '<S76>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S77>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Integrator/Discrete'
 * '<S78>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Integrator ICs/Internal IC'
 * '<S79>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/N Copy/Disabled wSignal Specification'
 * '<S80>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/N Gain/Disabled'
 * '<S81>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/P Copy/Disabled'
 * '<S82>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Parallel P Gain/External Parameters'
 * '<S83>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Reset Signal/Disabled'
 * '<S84>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Saturation/Enabled'
 * '<S85>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Saturation Fdbk/Disabled'
 * '<S86>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Sum/Sum_PI'
 * '<S87>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Sum Fdbk/Disabled'
 * '<S88>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tracking Mode/Disabled'
 * '<S89>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tracking Mode Sum/Passthrough'
 * '<S90>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tsamp - Integral/Passthrough'
 * '<S91>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/Tsamp - Ngain/Passthrough'
 * '<S92>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/postSat Signal/Forward_Path'
 * '<S93>'  : 'TV_old/Subsystem/Yaw rate controller/Feedback controller type/MPC controller type/Discrete PID Controller/preSat Signal/Forward_Path'
 * '<S94>'  : 'TV_old/Subsystem/Yaw rate reference calculation/MATLAB Function'
 */
#endif                                 /* RTW_HEADER_TV_old_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
